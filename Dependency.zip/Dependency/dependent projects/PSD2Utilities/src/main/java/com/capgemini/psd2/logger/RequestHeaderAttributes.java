/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.logger;

import java.util.List;
import java.util.UUID;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

import com.capgemini.psd2.token.Token;
import com.capgemini.psd2.utilities.GenerateUniqueIdUtilities;

/**
 * The Class RequestHeaderAttributes.
 */
@Component
@Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class RequestHeaderAttributes{
	
	/** The correlation id. */
	private String correlationId;
	
	/** The request id. */
	private UUID requestId = GenerateUniqueIdUtilities.getUniqueId();
	
	/** The tpp CID. */
	private String tppCID;
	
	/** The tpp legal entity name. */
	private String tppLegalEntityName;
	
	/** The by value token. */
	private Token byValueToken;
	
	/** The o auth URL. */
	private String oAuthURL;
	
	/** The psu id. */
	private String psuId;
	
	/** The claims. */
	private List<Object> claims;
	
	/** The customer IP address. */
	private String customerIPAddress;
	
	/** The customer last logged time. */
	private String customerLastLoggedTime;
	
	/** The financial id. */
	private String financialId;
	
	/** The self url. */
	private String selfUrl;
	
	
	
	
	/**
	 * Gets the self url.
	 *
	 * @return the self url
	 */
	public String getSelfUrl() {
		return selfUrl;
	}


	/**
	 * Sets the self url.
	 *
	 * @param selfUrl the new self url
	 */
	public void setSelfUrl(String selfUrl) {
		this.selfUrl = selfUrl;
	}


	/**
	 * Gets the correlation id.
	 *
	 * @return the correlation id
	 */
	public String getCorrelationId() {
		return correlationId;
	}


	/**
	 * Sets the correlation id.
	 *
	 * @param correlationId the new correlation id
	 */
	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}

	/**
	 * Gets the tpp CID.
	 *
	 * @return the tpp CID
	 */
	public String getTppCID() {
		return tppCID;
	}


	/**
	 * Gets the request id.
	 *
	 * @return the request id
	 */
	public UUID getRequestId() {
		return requestId;
	}


	/**
	 * Gets the tpp legal entity name.
	 *
	 * @return the tpp legal entity name
	 */
	public String getTppLegalEntityName() {
		return tppLegalEntityName;
	}


	/**
	 * Gets the by value token.
	 *
	 * @return the by value token
	 */
	public Token getByValueToken() {
		return byValueToken;
	}


	/**
	 * Sets the by value token.
	 *
	 * @param byValueToken the new by value token
	 */
	public void setByValueToken(Token byValueToken) {
		this.byValueToken = byValueToken;
	}


	/**
	 * Gets the o auth URL.
	 *
	 * @return the o auth URL
	 */
	public String getoAuthURL() {
		return oAuthURL;
	}


	/**
	 * Sets the o auth URL.
	 *
	 * @param oAuthURL the new o auth URL
	 */
	public void setoAuthURL(String oAuthURL) {
		this.oAuthURL = oAuthURL;
	}


	/**
	 * Gets the psu id.
	 *
	 * @return the psu id
	 */
	public String getPsuId() {
		return psuId;
	}

	/**
	 * Gets the claims.
	 *
	 * @return the claims
	 */
	public List<Object> getClaims() {
		return claims;
	}
	
	/**
	 * Gets the customer IP address.
	 *
	 * @return the customer IP address
	 */
	public String getCustomerIPAddress() {
		return customerIPAddress;
	}


	/**
	 * Sets the customer IP address.
	 *
	 * @param customerIPAddress the new customer IP address
	 */
	public void setCustomerIPAddress(String customerIPAddress) {
		this.customerIPAddress = customerIPAddress;
	}


	/**
	 * Gets the customer last logged time.
	 *
	 * @return the customer last logged time
	 */
	public String getCustomerLastLoggedTime() {
		return customerLastLoggedTime;
	}


	/**
	 * Sets the customer last logged time.
	 *
	 * @param customerLastLoggedTime the new customer last logged time
	 */
	public void setCustomerLastLoggedTime(String customerLastLoggedTime) {
		this.customerLastLoggedTime = customerLastLoggedTime;
	}


	/**
	 * Gets the financial id.
	 *
	 * @return the financial id
	 */
	public String getFinancialId() {
		return financialId;
	}


	/**
	 * Sets the financial id.
	 *
	 * @param financialId the new financial id
	 */
	public void setFinancialId(String financialId) {
		this.financialId = financialId;
	}

	

	/**
	 * Sets the attributes.
	 *
	 * @param token the new attributes
	 */
	public void setAttributes(Token token){
		this.tppCID = token.getTppCID();
		this.tppLegalEntityName = token.getTppLegalEntityName();
		this.psuId = token.getPsuId();
		this.byValueToken = token;
	}


	/**
	 * Sets the claims.
	 *
	 * @param claims the new claims
	 */
	public void setClaims(List<Object> claims) {
		this.claims = claims;
	}

}
