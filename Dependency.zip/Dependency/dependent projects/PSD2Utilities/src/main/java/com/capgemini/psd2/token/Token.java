/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.token;

import java.util.List;
import java.util.Map;

/**
 * The Class Token.
 */
public class Token{
	
	/** The consent id. */
	private String consentId;
	
	/** The brand id. */
	private String brandId;
	
	/** The channel id. */
	private String channelId;
	
	/** The psu id. */
	private String psuId;
	
	/** The tpp CID. */
	private String tppCID;
	
	/** The tpp legal entity name. */
	private String tppLegalEntityName;
	
	/** The account request id. */
	private String accountRequestId;
	
	/** The scope. */
	private List<String> scope;
	
	/** The claims. */
	private Map<String, List<Object>> claims;
	
	/** The roles. */
	private List<String> roles;
	
	/** The jti. */
	private String jti;
	
	/** The exp. */
	private long exp;
	
	/** The consent expiry. */
	private long consentExpiry;
	
	/** The last SCA date time. */
	private long lastSCADateTime;
	
	/** The iat. */
	private long iat;
	
	
	/**
	 * Gets the iat.
	 *
	 * @return the iat
	 */
	public long getIat() {
		return iat;
	}
	
	/**
	 * Sets the iat.
	 *
	 * @param iat the new iat
	 */
	public void setIat(long iat) {
		this.iat = iat;
	}
	
	/**
	 * Gets the consent id.
	 *
	 * @return the consent id
	 */
	public String getConsentId() {
		return consentId;
	}
	
	/**
	 * Sets the consent id.
	 *
	 * @param consentId the new consent id
	 */
	public void setConsentId(String consentId) {
		this.consentId = consentId;
	}
	
	/**
	 * Gets the brand id.
	 *
	 * @return the brand id
	 */
	public String getBrandId() {
		return brandId;
	}
	
	/**
	 * Sets the brand id.
	 *
	 * @param brandId the new brand id
	 */
	public void setBrandId(String brandId) {
		this.brandId = brandId;
	}
	
	/**
	 * Gets the channel id.
	 *
	 * @return the channel id
	 */
	public String getChannelId() {
		return channelId;
	}
	
	/**
	 * Sets the channel id.
	 *
	 * @param channelId the new channel id
	 */
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	
	/**
	 * Gets the psu id.
	 *
	 * @return the psu id
	 */
	public String getPsuId() {
		return psuId;
	}
	
	/**
	 * Sets the psu id.
	 *
	 * @param psuId the new psu id
	 */
	public void setPsuId(String psuId) {
		this.psuId = psuId;
	}
	
	/**
	 * Gets the tpp CID.
	 *
	 * @return the tpp CID
	 */
	public String getTppCID() {
		return tppCID;
	}
	
	/**
	 * Sets the tpp CID.
	 *
	 * @param tppCID the new tpp CID
	 */
	public void setTppCID(String tppCID) {
		this.tppCID = tppCID;
	}
	
	/**
	 * Gets the tpp legal entity name.
	 *
	 * @return the tpp legal entity name
	 */
	public String getTppLegalEntityName() {
		return tppLegalEntityName;
	}
	
	/**
	 * Sets the tpp legal entity name.
	 *
	 * @param tppLegalEntityName the new tpp legal entity name
	 */
	public void setTppLegalEntityName(String tppLegalEntityName) {
		this.tppLegalEntityName = tppLegalEntityName;
	}
	
	/**
	 * Gets the account request id.
	 *
	 * @return the account request id
	 */
	public String getAccountRequestId() {
		return accountRequestId;
	}
	
	/**
	 * Sets the account request id.
	 *
	 * @param accountRequestId the new account request id
	 */
	public void setAccountRequestId(String accountRequestId) {
		this.accountRequestId = accountRequestId;
	}
	
	/**
	 * Gets the scope.
	 *
	 * @return the scope
	 */
	public List<String> getScope() {
		return scope;
	}
	
	/**
	 * Sets the scope.
	 *
	 * @param scope the new scope
	 */
	public void setScope(List<String> scope) {
		this.scope = scope;
	}
	
	/**
	 * Gets the claims.
	 *
	 * @return the claims
	 */
	public Map<String, List<Object>> getClaims() {
		return claims;
	}
	
	/**
	 * Sets the claims.
	 *
	 * @param claims the claims
	 */
	public void setClaims(Map<String, List<Object>> claims) {
		this.claims = claims;
	}
	
	/**
	 * Gets the roles.
	 *
	 * @return the roles
	 */
	public List<String> getRoles() {
		return roles;
	}
	
	/**
	 * Sets the roles.
	 *
	 * @param roles the new roles
	 */
	public void setRoles(List<String> roles) {
		this.roles = roles;
	}
	
	/**
	 * Gets the jti.
	 *
	 * @return the jti
	 */
	public String getJti() {
		return jti;
	}
	
	/**
	 * Sets the jti.
	 *
	 * @param jti the new jti
	 */
	public void setJti(String jti) {
		this.jti = jti;
	}
	
	/**
	 * Gets the exp.
	 *
	 * @return the exp
	 */
	public long getExp() {
		return exp;
	}
	
	/**
	 * Sets the exp.
	 *
	 * @param exp the new exp
	 */
	public void setExp(long exp) {
		this.exp = exp;
	}
	
	/**
	 * Gets the consent expiry.
	 *
	 * @return the consent expiry
	 */
	public long getConsentExpiry() {
		return consentExpiry;
	}
	
	/**
	 * Sets the consent expiry.
	 *
	 * @param consentExpiry the new consent expiry
	 */
	public void setConsentExpiry(long consentExpiry) {
		this.consentExpiry = consentExpiry;
	}
	
	/**
	 * Gets the last SCA date time.
	 *
	 * @return the last SCA date time
	 */
	public long getLastSCADateTime() {
		return lastSCADateTime;
	}
	
	/**
	 * Sets the last SCA date time.
	 *
	 * @param lastSCADateTime the new last SCA date time
	 */
	public void setLastSCADateTime(long lastSCADateTime) {
		this.lastSCADateTime = lastSCADateTime;
	}
}
