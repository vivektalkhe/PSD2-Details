/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.utilities;

import java.io.Serializable;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.Security;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import com.capgemini.psd2.exceptions.ErrorCodeEnum;
import com.capgemini.psd2.exceptions.PSD2Exception;

/**
 * The Class CryptoUtilities.
 */
public final class CryptoUtilities implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	

	/**
	 * Instantiates a new crypto utilities.
	 */
	private CryptoUtilities() {

	}

	static {
		Security.addProvider(new BouncyCastleProvider());
	}
	
	
	/**
	 * Enc pay load.
	 *
	 * @param plainText the plain text
	 * @param tokenSigningKey the token signing key
	 * @return the string
	 */
	public static String encPayLoad(String plainText,String tokenSigningKey){
		String encrypted = null;
		Key skeySpec = new SecretKeySpec(tokenSigningKey.getBytes(), "AES");
		try {
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
			encrypted = Base64.encodeBase64String(cipher.doFinal(plainText.getBytes()));
		}
		catch (NoSuchAlgorithmException  | NoSuchPaddingException 
				| InvalidKeyException | IllegalBlockSizeException | BadPaddingException e) {
			throw PSD2Exception.populatePSD2Exception(e.getMessage(), ErrorCodeEnum.CRYPTO_TECHNICAL_ERROR);
		}
        return encrypted;
	}	    
	
	
	/**
	 * Decrypt pay load.
	 *
	 * @param encryptedText the encrypted text
	 * @param tokenSigningKey the token signing key
	 * @return the string
	 */
	public static String decryptPayLoad(String encryptedText,String tokenSigningKey) {
		String originalText = null;
        Cipher cipher = null;
        String revisdEncryptedTxt;
        revisdEncryptedTxt = encryptedText.replaceAll(" ","+");
        byte[] raw = tokenSigningKey.getBytes();
		Key skeySpec = new SecretKeySpec(raw, "AES");
        try {
        	 cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
             cipher.init(Cipher.DECRYPT_MODE, skeySpec);
             originalText = new String(cipher.doFinal(Base64.decodeBase64(revisdEncryptedTxt)));
	    } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | IllegalBlockSizeException | BadPaddingException  e) {
			throw PSD2Exception.populatePSD2Exception(e.getMessage(), ErrorCodeEnum.CRYPTO_TECHNICAL_ERROR);
		}
        return originalText; 
	}	
		
}
