/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.logger;

import java.util.UUID;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

import com.capgemini.psd2.utilities.DateUtilites;

/**
 * The Class LoggerAttribute.
 */
@Component
@Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class LoggerAttribute{

	/** The request id. */
	private UUID requestId;
	
	/** The correlation id. */
	private String correlationId;
	
	/** The api id. */
	private String apiId;
	
	/** The tpp CID. */
	private String tppCID;
	
	/** The tpp legal entity name. */
	private String tppLegalEntityName;
	
	/** The message. */
	private String message;
	
	/** The psu id. */
	private String psuId;
	
	/** The customer IP address. */
	private String customerIPAddress;
	
	/** The customer last logged time. */
	private String customerLastLoggedTime;
	
	/** The financial id. */
	private String financialId;
	

	
	/**
	 * Gets the request id.
	 *
	 * @return the request id
	 */
	public UUID getRequestId() {
		return requestId;
	}


	/**
	 * Sets the request id.
	 *
	 * @param requestId the new request id
	 */
	public void setRequestId(UUID requestId) {
		this.requestId = requestId;
	}


	/**
	 * Gets the correlation id.
	 *
	 * @return the correlation id
	 */
	public String getCorrelationId() {
		return correlationId;
	}


	/**
	 * Sets the correlation id.
	 *
	 * @param correlationId the new correlation id
	 */
	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}


	/**
	 * Gets the api id.
	 *
	 * @return the api id
	 */
	public String getApiId() {
		return apiId;
	}


	/**
	 * Sets the api id.
	 *
	 * @param apiId the new api id
	 */
	public void setApiId(String apiId) {
		this.apiId = apiId;
	}


	/**
	 * Gets the tpp CID.
	 *
	 * @return the tpp CID
	 */
	public String getTppCID() {
		return tppCID;
	}


	/**
	 * Sets the tpp CID.
	 *
	 * @param tppCID the new tpp CID
	 */
	public void setTppCID(String tppCID) {
		this.tppCID = tppCID;
	}


	/**
	 * Gets the tpp legal entity name.
	 *
	 * @return the tpp legal entity name
	 */
	public String getTppLegalEntityName() {
		return tppLegalEntityName;
	}


	/**
	 * Sets the tpp legal entity name.
	 *
	 * @param tppLegalEntityName the new tpp legal entity name
	 */
	public void setTppLegalEntityName(String tppLegalEntityName) {
		this.tppLegalEntityName = tppLegalEntityName;
	}


	/**
	 * Gets the message.
	 *
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}


	/**
	 * Sets the message.
	 *
	 * @param message the new message
	 */
	public void setMessage(String message) {
		this.message = message;
	}


	/**
	 * Gets the psu id.
	 *
	 * @return the psu id
	 */
	public String getPsuId() {
		return psuId;
	}


	/**
	 * Sets the psu id.
	 *
	 * @param psuId the new psu id
	 */
	public void setPsuId(String psuId) {
		this.psuId = psuId;
	}
	
	/**
	 * Gets the customer IP address.
	 *
	 * @return the customer IP address
	 */
	public String getCustomerIPAddress() {
		return customerIPAddress;
	}


	/**
	 * Sets the customer IP address.
	 *
	 * @param customerIPAddress the new customer IP address
	 */
	public void setCustomerIPAddress(String customerIPAddress) {
		this.customerIPAddress = customerIPAddress;
	}


	/**
	 * Gets the customer last logged time.
	 *
	 * @return the customer last logged time
	 */
	public String getCustomerLastLoggedTime() {
		return customerLastLoggedTime;
	}


	/**
	 * Sets the customer last logged time.
	 *
	 * @param customerLastLoggedTime the new customer last logged time
	 */
	public void setCustomerLastLoggedTime(String customerLastLoggedTime) {
		this.customerLastLoggedTime = customerLastLoggedTime;
	}


	/**
	 * Gets the financial id.
	 *
	 * @return the financial id
	 */
	public String getFinancialId() {
		return financialId;
	}


	/**
	 * Sets the financial id.
	 *
	 * @param financialId the new financial id
	 */
	public void setFinancialId(String financialId) {
		this.financialId = financialId;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "timestamp\":\"" + DateUtilites.generateCurrentTimeStamp() + "\",\"requestId\":\"" + requestId + "\",\"correlationId\":\""
				+ correlationId + "\",\"financialId\":\"" + financialId + "\",\"customerIPAddress\":\"" + customerIPAddress 
				+ "\",\"customerLastLoggedTime\":\"" + customerLastLoggedTime +"\",\"apiId\":\"" + apiId + "\",\"tppCID\":\"" + tppCID + "\",\"tppLegalEntityName\":\"" + tppLegalEntityName + "\",\"psuId\":\"" + psuId + "\",\"message\":\""
				+ message;
	}

}
