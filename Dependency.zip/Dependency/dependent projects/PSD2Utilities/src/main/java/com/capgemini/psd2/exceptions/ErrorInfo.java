/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.exceptions;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * The Class ErrorInfo.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class ErrorInfo implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The error code. */
	private String errorCode;
	
	/** The error message. */
	private String errorMessage;
	
	/** The detail error message. */
	private String detailErrorMessage;
	
	/** The jti. */
	private String jti;
	
	/** The status code. */
	@JsonIgnore
	private String statusCode;
	
	/** The oauth server token refresh URL. */
	private String oauthServerTokenRefreshURL;
	
	/**
	 * Gets the error code.
	 *
	 * @return the error code
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * Sets the error code.
	 *
	 * @param errorCode the new error code
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * Gets the error message.
	 *
	 * @return the error message
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * Sets the error message.
	 *
	 * @param errorMessage the new error message
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * Gets the detail error message.
	 *
	 * @return the detail error message
	 */
	public String getDetailErrorMessage() {
		return detailErrorMessage;
	}

	/**
	 * Sets the detail error message.
	 *
	 * @param detailErrorMessage the new detail error message
	 */
	public void setDetailErrorMessage(String detailErrorMessage) {
		this.detailErrorMessage = detailErrorMessage;
	}

	/**
	 * Gets the jti.
	 *
	 * @return the jti
	 */
	public String getJti() {
		return jti;
	}

	/**
	 * Sets the jti.
	 *
	 * @param jti the new jti
	 */
	public void setJti(String jti) {
		this.jti = jti;
	}
	
	/**
	 * Gets the status code.
	 *
	 * @return the status code
	 */
	public String getStatusCode() {
		return statusCode;
	}

	/**
	 * Sets the status code.
	 *
	 * @param statusCode the new status code
	 */
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * Gets the oauth server token refresh URL.
	 *
	 * @return the oauth server token refresh URL
	 */
	public String getOauthServerTokenRefreshURL() {
		return oauthServerTokenRefreshURL;
	}

	/**
	 * Sets the oauth server token refresh URL.
	 *
	 * @param oauthServerTokenRefreshURL the new oauth server token refresh URL
	 */
	public void setOauthServerTokenRefreshURL(String oauthServerTokenRefreshURL) {
		this.oauthServerTokenRefreshURL = oauthServerTokenRefreshURL;
	}

	/**
	 * To message.
	 *
	 * @return the string
	 */
	public String toMessage() {
		return "ErrorInfo [errorCode=" + errorCode + ", errorMessage=" + errorMessage + ", detailErrorMessage="
				+ detailErrorMessage + ", statusCode="+statusCode+"]";
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "{\"errorCode\":\"" + errorCode + "\",\"errorMessage\":\"" + errorMessage + "\",\"detailErrorMessage\":\""
				+ detailErrorMessage +"\",\"statusCode\":\""+statusCode+"\"}";
	}
	
	
}
