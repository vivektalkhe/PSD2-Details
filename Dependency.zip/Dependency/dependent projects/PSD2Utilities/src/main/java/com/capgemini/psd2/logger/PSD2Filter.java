/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.logger;

import java.io.IOException;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.security.jwt.Jwt;
import org.springframework.security.jwt.JwtHelper;
import org.springframework.web.filter.OncePerRequestFilter;

import com.capgemini.psd2.exceptions.ErrorCodeEnum;
import com.capgemini.psd2.exceptions.PSD2Exception;
import com.capgemini.psd2.token.AispTokens;
import com.capgemini.psd2.token.Token;
import com.capgemini.psd2.token.TokenRepository;
import com.capgemini.psd2.utilities.GenerateUniqueIdUtilities;
import com.capgemini.psd2.utilities.JSONUtilities;
import com.capgemini.psd2.utilities.NullCheckUtils;

/**
 * The Class PSD2Filter.
 */
public class PSD2Filter extends OncePerRequestFilter {

	/** The Constant LOG. */
	private static final Logger LOG = LoggerFactory.getLogger(PSD2Filter.class);

	/** The req header attribute. */
	@Autowired
	private RequestHeaderAttributes reqHeaderAttribute;

	/** The logger utils. */
	@Autowired
	private LoggerUtils loggerUtils;

	/** The token repository. */
	@Autowired
	private TokenRepository tokenRepository;

	/* (non-Javadoc)
	 * @see org.springframework.web.filter.OncePerRequestFilter#doFilterInternal(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, javax.servlet.FilterChain)
	 */
	@Override
	protected void doFilterInternal(HttpServletRequest httpServletRequest, HttpServletResponse servletResponse,
			FilterChain filterChain) throws ServletException, IOException {

		try{
			String currentCorrId = httpServletRequest.getHeader(PSD2Constants.CORRELATION_ID);
			if (NullCheckUtils.isNullOrEmpty(currentCorrId)) {
				currentCorrId = GenerateUniqueIdUtilities.getUniqueId().toString();
				httpServletRequest.setAttribute(PSD2Constants.CORRELATION_ID, currentCorrId);
				reqHeaderAttribute.setCorrelationId(currentCorrId);
				LOG.info("{\"Enter\":\"{}\",\"preCorrelationId\":\"Not Found\",\"remoteAddress\":\"{}\",\"hostName\":\"{}\",\"{}\"}",
						"com.capgemini.psd2.logger.PSD2Filter.doFilterInternal()",httpServletRequest.getRemoteAddr(), httpServletRequest.getRemoteHost(), loggerUtils.populateLoggerData());
			} else {
				reqHeaderAttribute.setCorrelationId(currentCorrId);
				LOG.info("{\"Enter\":\"{}\",\"preCorrelationId\":\"Found\",\"remoteAddress\":\"{}\",\"hostName\":\"{}\",\"{}\"}",
						"com.capgemini.psd2.logger.PSD2Filter.doFilterInternal()",httpServletRequest.getRemoteAddr(), httpServletRequest.getRemoteHost(), loggerUtils.populateLoggerData());
			}
			servletResponse.addHeader(PSD2Constants.CORRELATION_ID, currentCorrId);
			reqHeaderAttribute.setSelfUrl(httpServletRequest.getRequestURI());
			String bearerToken = httpServletRequest.getHeader("Authorization");
			if(bearerToken != null && bearerToken.contains("Bearer") && bearerToken.split("Bearer")[1] != null){
				validateAndSetHeaders(httpServletRequest);
				bearerToken = bearerToken.split("Bearer ")[1];
				Map token = convertByReftoToken(bearerToken);
				AispTokens aispToken = null;
				try {
					aispToken = tokenRepository.findByJti((String) token.get("jti"));
				} catch (DataAccessResourceFailureException e) {
					throw PSD2Exception.populatePSD2Exception(e.getMessage(), ErrorCodeEnum.CONNECTION_ERROR);
				}
				if (aispToken == null) {
					throw PSD2Exception.populatePSD2Exception(ErrorCodeEnum.NO_SUCH_TOKEN_GENERATED_BY_OAUTH);
				}
				Token byValueToken = convertByValuetoToken(aispToken.getToken());
				reqHeaderAttribute.setAttributes(byValueToken);
			}
			filterChain.doFilter(httpServletRequest, servletResponse);
			LOG.info("{\"Exit\":\"{}\",\"{}\"}",
					"com.capgemini.psd2.logger.PSD2Filter.doFilterInternal()", loggerUtils.populateLoggerData());

		} 
		catch (PSD2Exception e) {
			LOG.error("{\"Exception\":\"{}\",\"{}\",\"ErrorDetails\":{}}" ,
					"com.capgemini.psd2.logger.PSD2Filter.doFilterInternal()", loggerUtils.populateLoggerData(), e.getErrorInfo());
			if(LOG.isDebugEnabled()){
				LOG.error("{\"Exception\":\"{}\",\"{}\",\"ErrorDetails\":\"{}\"}" ,
						"com.capgemini.psd2.logger.PSD2Filter.doFilterInternal()", loggerUtils.populateLoggerData(), e.getStackTrace(), e);
			}
			servletResponse.setContentType("application/json");
			servletResponse.setStatus(Integer.parseInt(e.getErrorInfo().getStatusCode()));
			servletResponse.getWriter().write(JSONUtilities.getJSONOutPutFromObject(e.getErrorInfo()));
		} catch (Exception e) {
			PSD2Exception psd2Exception = PSD2Exception.populatePSD2Exception(e.getMessage(),
					ErrorCodeEnum.TECHNICAL_ERROR);
			LOG.error("{\"Exception\":\"{}\",\"{}\",\"ErrorDetails\":{}}" ,
					"com.capgemini.psd2.logger.PSD2Filter.doFilterInternal()", loggerUtils.populateLoggerData(), psd2Exception.getErrorInfo());
			if(LOG.isDebugEnabled()){
				LOG.error("{\"Exception\":\"{}\",\"{}\",\"ErrorDetails\":\"{}\"}" ,
						"com.capgemini.psd2.logger.PSD2Filter.doFilterInternal()", loggerUtils.populateLoggerData(), e.getStackTrace(), e);
			}
			servletResponse.setContentType("application/json");
			servletResponse.setStatus(Integer.parseInt(psd2Exception.getErrorInfo().getStatusCode()));
			servletResponse.getWriter().write(JSONUtilities.getJSONOutPutFromObject(psd2Exception.getErrorInfo()));
		}
	}

	/**
	 * Validate and set headers.
	 *
	 * @param httpServletRequest the http servlet request
	 */
	private void validateAndSetHeaders(HttpServletRequest httpServletRequest){
		String financialId = httpServletRequest.getHeader(PSD2Constants.FINANCIAL_ID);
		if(StringUtils.isBlank(financialId)){
			throw PSD2Exception.populatePSD2Exception(PSD2Constants.FINANCIAL_ID+" is missing in headers.",ErrorCodeEnum.HEADER_MISSING);
		}
		reqHeaderAttribute.setFinancialId(financialId);
		reqHeaderAttribute.setCustomerIPAddress(httpServletRequest.getHeader(PSD2Constants.CUSTOMER_IP_ADDRESS));
		reqHeaderAttribute.setCustomerLastLoggedTime(httpServletRequest.getHeader(PSD2Constants.CUSTOMER_LAST_LOGGED_TIME));
	}

	/**
	 * Convert by refto token.
	 *
	 * @param token the token
	 * @return the map
	 */
	private Map convertByReftoToken(String token){
		try{
			Jwt jwt = JwtHelper.decode(token);
			return JSONUtilities.getObjectFromJSONString(jwt.getClaims(),Map.class);
		} catch(Exception ex){
			throw PSD2Exception.populatePSD2Exception(ErrorCodeEnum.INVALID_ACCESS_TOKEN);
		}
	}
	
	/**
	 * Convert by valueto token.
	 *
	 * @param token the token
	 * @return the token
	 */
	private Token convertByValuetoToken(String token){
		try{
			return JSONUtilities.getObjectFromJSONString(JwtHelper.decode(token).getClaims(),Token.class);
		} catch(Exception ex){
			throw PSD2Exception.populatePSD2Exception(ErrorCodeEnum.INVALID_ACCESS_TOKEN);
		}
	}
	

}
