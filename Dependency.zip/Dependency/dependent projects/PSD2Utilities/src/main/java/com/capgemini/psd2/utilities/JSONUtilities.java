/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.utilities;

import java.io.IOException;
import java.io.Serializable;

import com.capgemini.psd2.exceptions.ErrorCodeEnum;
import com.capgemini.psd2.exceptions.PSD2Exception;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * The Class JSONUtilities.
 */
public final class JSONUtilities implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The mapper. */
	private static ObjectMapper mapper = null;
	
	/**
	 * Instantiates a new JSON utilities.
	 */
	private JSONUtilities(){
		
	}
	
	static {
		mapper = new ObjectMapper();
	}
	
	/**
	 * Gets the JSON out put from object.
	 *
	 * @param <T> the generic type
	 * @param obj the obj
	 * @return the JSON out put from object
	 */
	public static <T> String getJSONOutPutFromObject(T obj) {
		String jsonString = null;
		try{
			jsonString = mapper.writeValueAsString(obj);
		}
		catch(JsonProcessingException je) {
			throw PSD2Exception.populatePSD2Exception(je.getMessage(),ErrorCodeEnum.JSON_PROCESSING_ERROR);
		}
		return jsonString;
	}
	
	/**
	 * Gets the object from JSON string.
	 *
	 * @param <T> the generic type
	 * @param jsonString the json string
	 * @param classType the class type
	 * @return the object from JSON string
	 */
	public static <T> T getObjectFromJSONString(String jsonString,Class<T> classType) {
		T obj = null;
		try {
			obj = mapper.readValue(jsonString, classType);
		} catch (IOException e) {
			throw PSD2Exception.populatePSD2Exception(e.getMessage(),ErrorCodeEnum.JSON_PROCESSING_ERROR);
		}
		return obj; 
	}
	
	/**
	 * Gets the object from JSON string.
	 *
	 * @param <T> the generic type
	 * @param jsonString the json string
	 * @param obj the obj
	 * @return the object from JSON string
	 */
	public static <T> T getObjectFromJSONString(String jsonString, T obj) {
		T jsonObj = null;
		try {
			jsonObj = mapper.readerForUpdating(obj).readValue(jsonString);
		} catch (IOException e) {
			throw PSD2Exception.populatePSD2Exception(e.getMessage(),ErrorCodeEnum.JSON_PROCESSING_ERROR);
		}
		return jsonObj;
	}
}
