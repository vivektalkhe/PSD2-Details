/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.aspect;

import java.util.Arrays;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.capgemini.psd2.exceptions.ErrorCodeEnum;
import com.capgemini.psd2.exceptions.PSD2Exception;
import com.capgemini.psd2.filteration.ResponseFilter;
import com.capgemini.psd2.logger.LoggerAttribute;
import com.capgemini.psd2.logger.LoggerUtils;
import com.capgemini.psd2.mask.DataMask;
import com.capgemini.psd2.utilities.JSONUtilities;

/**
 * The Class PSD2Aspect.
 */
@Component
@Aspect
public class PSD2Aspect {


	/** The data mask. */
	@Autowired
	private DataMask dataMask;

	/** The payload log. */
	@Value("${app.payloadLog:#{false}}")
	private boolean payloadLog;

	/** The mask payload log. */
	@Value("${app.maskPayloadLog:#{false}}")
	private boolean maskPayloadLog;
	
	/** The mask payload. */
	@Value("${app.maskPayload:#{false}}")
	private boolean maskPayload;

	/** The logger attribute. */
	@Autowired
	private LoggerAttribute loggerAttribute;

	/** The logger utils. */
	@Autowired
	private LoggerUtils loggerUtils;
	
	/** The response filter utility. */
	@Autowired
	private ResponseFilter responseFilterUtility;
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(PSD2Aspect.class);

	/**
	 * Arround logger advice service.
	 *
	 * @param proceedingJoinPoint the proceeding join point
	 * @return the object
	 */
	@Around("(execution(* com.capgemini.psd2..service..*.* (..)))")
	public Object arroundLoggerAdviceService(ProceedingJoinPoint proceedingJoinPoint) {
		loggerUtils.populateLoggerData();
		loggerAttribute.setMessage("Starting method Execution : " + proceedingJoinPoint.getSignature().getName());
		LOGGER.info("{\"Enter\":\"{}.{}()\",\"{}\"}",
				proceedingJoinPoint.getSignature().getDeclaringTypeName(), proceedingJoinPoint.getSignature().getName(),
				loggerAttribute);
		try {
			Object result = proceedingJoinPoint.proceed();
			loggerAttribute.setMessage("Successfully completed method Execution : "
					+ proceedingJoinPoint.getSignature().getName());
			LOGGER.info("{\"Exit\":\"{}.{}()\",\"{}\"}",
					proceedingJoinPoint.getSignature().getDeclaringTypeName(),
					proceedingJoinPoint.getSignature().getName(), loggerAttribute);
			return result;
		} catch(PSD2Exception e){
			loggerAttribute.setMessage("Exception: "+e.getErrorInfo().toMessage());
			LOGGER.error("{\"Exception\":\"{}.{}()\",\"{}\",\"ErrorDetails\":{}}" ,
					proceedingJoinPoint.getSignature().getDeclaringTypeName(),
					proceedingJoinPoint.getSignature().getName(), loggerAttribute, e.getErrorInfo());
			if(LOGGER.isDebugEnabled()){
				LOGGER.error("{\"Exception\":\"{}.{}()\",\"{}\",\"ErrorDetails\":\"{}\"}",proceedingJoinPoint.getSignature().getDeclaringTypeName(),
						proceedingJoinPoint.getSignature().getName(), loggerAttribute, e.getStackTrace());
			}
			throw e;
		}
		catch (Throwable e) {
			PSD2Exception psd2Exception = PSD2Exception.populatePSD2Exception(e.getMessage(), ErrorCodeEnum.TECHNICAL_ERROR);
			loggerAttribute.setMessage("Exception: "+psd2Exception.getErrorInfo().toMessage());
			LOGGER.error("{\"Exception\":\"{}.{}()\",\"{}\",\"ErrorDetails\":{}}" ,
					proceedingJoinPoint.getSignature().getDeclaringTypeName(),
					proceedingJoinPoint.getSignature().getName(), loggerAttribute, psd2Exception.getErrorInfo());
			if(LOGGER.isDebugEnabled()){
				LOGGER.error("{\"Exception\":\"{}.{}()\",\"{}\",\"ErrorDetails\":\"{}\"}",proceedingJoinPoint.getSignature().getDeclaringTypeName(),
						proceedingJoinPoint.getSignature().getName(), loggerAttribute, e.getStackTrace());
			}
			throw psd2Exception;
		}
	}

	/**
	 * Arround logger advice controller.
	 *
	 * @param proceedingJoinPoint the proceeding join point
	 * @return the object
	 */
	@Around("(execution(* com.capgemini.psd2..controller..* (..)))")
	public Object arroundLoggerAdviceController(ProceedingJoinPoint proceedingJoinPoint) {
		loggerUtils.populateLoggerData();
		if(maskPayloadLog && payloadLog){
			loggerAttribute.setMessage("Starting method Execution : " + proceedingJoinPoint.getSignature().getName()
					+ Arrays.toString(dataMask.maskRequestLog(proceedingJoinPoint.getArgs(), proceedingJoinPoint.getSignature().getName())));
			LOGGER.info("{\"Enter\":\"{}.{}()\",\"{}\",\"Arguments\":{}}",
					proceedingJoinPoint.getSignature().getDeclaringTypeName(), proceedingJoinPoint.getSignature().getName(),
					loggerAttribute, JSONUtilities.getJSONOutPutFromObject(dataMask.maskRequestLog(proceedingJoinPoint.getArgs(), proceedingJoinPoint.getSignature().getName())));

		}else if(!maskPayloadLog && payloadLog){
			loggerAttribute.setMessage("Starting method Execution : " + proceedingJoinPoint.getSignature().getName()
					+ Arrays.toString(proceedingJoinPoint.getArgs()));
			LOGGER.info("{\"Enter\":\"{}.{}()\",\"{}\",\"Arguments\":{}}",
					proceedingJoinPoint.getSignature().getDeclaringTypeName(), proceedingJoinPoint.getSignature().getName(),
					loggerAttribute, JSONUtilities.getJSONOutPutFromObject(dataMask.maskMRequestLog(proceedingJoinPoint.getArgs(), proceedingJoinPoint.getSignature().getName())));

		}else{
			loggerAttribute.setMessage("Starting method Execution : " + proceedingJoinPoint.getSignature().getName());
			LOGGER.info("{\"Enter\":\"{}.{}()\",\"{}\"}",
					proceedingJoinPoint.getSignature().getDeclaringTypeName(), proceedingJoinPoint.getSignature().getName(),
					loggerAttribute);

		}
		try {
			
			Object result = proceedingJoinPoint.proceed();
			result = responseFilterUtility.filterResponse(result, proceedingJoinPoint.getSignature().getName());

			if(maskPayload)
				dataMask.maskResponse(result,  proceedingJoinPoint.getSignature().getName());
			else
				dataMask.maskMResponse(result,  proceedingJoinPoint.getSignature().getName());
			if(maskPayloadLog && payloadLog){
				loggerAttribute.setMessage("Successfully completed method Execution : "
						+ proceedingJoinPoint.getSignature().getName() + Arrays.toString(dataMask.maskRequestLog(proceedingJoinPoint.getArgs(), proceedingJoinPoint.getSignature().getName())));
				LOGGER.info("{\"Exit\":\"{}.{}()\",\"{}\",\"Arguments\":{},\"Payload\":{}}",
						proceedingJoinPoint.getSignature().getDeclaringTypeName(),
						proceedingJoinPoint.getSignature().getName(), loggerAttribute,
						JSONUtilities.getJSONOutPutFromObject(dataMask.maskRequestLog(proceedingJoinPoint.getArgs(), proceedingJoinPoint.getSignature().getName())),JSONUtilities.getJSONOutPutFromObject(dataMask.maskResponseLog(result, proceedingJoinPoint.getSignature().getName())));
			}else if(!maskPayloadLog && payloadLog){
				loggerAttribute.setMessage("Successfully completed method Execution : "
						+ proceedingJoinPoint.getSignature().getName() + proceedingJoinPoint.getArgs());
				LOGGER.info("{\"Exit\":\"{}.{}()\",\"{}\",\"Arguments\":{},\"Payload\":{}}",
						proceedingJoinPoint.getSignature().getDeclaringTypeName(),
						proceedingJoinPoint.getSignature().getName(), loggerAttribute,
						JSONUtilities.getJSONOutPutFromObject(dataMask.maskMRequestLog(proceedingJoinPoint.getArgs(), proceedingJoinPoint.getSignature().getName())),JSONUtilities.getJSONOutPutFromObject(dataMask.maskMResponseLog(result, proceedingJoinPoint.getSignature().getName())));
			}else{
				loggerAttribute.setMessage("Successfully completed method Execution : "
						+ proceedingJoinPoint.getSignature().getName());
				LOGGER.info("{\"Exit\":\"{}.{}()\",\"{}\"}",
						proceedingJoinPoint.getSignature().getDeclaringTypeName(),
						proceedingJoinPoint.getSignature().getName(), loggerAttribute);
			}
			return result;
		} catch(PSD2Exception e){
			loggerAttribute.setMessage("Exception: "+e.getErrorInfo().toMessage());
			LOGGER.error("{\"Exception\":\"{}.{}()\",\"{}\",\"ErrorDetails\":{}}" ,
					proceedingJoinPoint.getSignature().getDeclaringTypeName(),
					proceedingJoinPoint.getSignature().getName(), loggerAttribute, e.getErrorInfo());
			if(LOGGER.isDebugEnabled()){
				LOGGER.error("{\"Exception\":\"{}.{}()\",\"{}\",\"ErrorDetails\":\"{}\"}",proceedingJoinPoint.getSignature().getDeclaringTypeName(),
						proceedingJoinPoint.getSignature().getName(), loggerAttribute, e.getStackTrace());
			}
			throw e;
		}
		catch (Throwable e) {
			PSD2Exception psd2Exception = PSD2Exception.populatePSD2Exception(e.getMessage(), ErrorCodeEnum.TECHNICAL_ERROR);
			loggerAttribute.setMessage("Exception: "+psd2Exception.getErrorInfo().toMessage());
			LOGGER.error("{\"Exception\":\"{}.{}()\",\"{}\",\"ErrorDetails\":{}}" ,
					proceedingJoinPoint.getSignature().getDeclaringTypeName(),
					proceedingJoinPoint.getSignature().getName(), loggerAttribute, psd2Exception.getErrorInfo());
			if(LOGGER.isDebugEnabled()){
				LOGGER.error("{\"Exception\":\"{}.{}()\",\"{}\",\"ErrorDetails\":\"{}\"}",proceedingJoinPoint.getSignature().getDeclaringTypeName(),
						proceedingJoinPoint.getSignature().getName(), loggerAttribute, e.getStackTrace());
			}
			throw psd2Exception;
		}
	}
	
}
