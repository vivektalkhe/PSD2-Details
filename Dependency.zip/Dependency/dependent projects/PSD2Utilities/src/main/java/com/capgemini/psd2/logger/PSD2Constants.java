/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.logger;

/**
 * The Class PSD2Constants.
 */
public class PSD2Constants {
	
	/** The Constant CORRELATION_ID. */
	public static final String CORRELATION_ID = "x-fapi-interaction-id";
	
	/** The Constant ACCESS_TOKEN_NAME. */
	public static final String ACCESS_TOKEN_NAME = "Authorization";
    
    /** The Constant COLON. */
    public static final String COLON = ":";
    
    /** The Constant SEMI_COLON. */
    public static final String SEMI_COLON = ";";
    
    /** The Constant COMMA. */
    public static final String COMMA = ",";
    
    /** The Constant CUSTOMER_IP_ADDRESS. */
    public static final String CUSTOMER_IP_ADDRESS="x-fapi-customer-ip-address";
    
    /** The Constant CUSTOMER_LAST_LOGGED_TIME. */
    public static final String CUSTOMER_LAST_LOGGED_TIME="x-fapi-customer-last-logged-time";
    
    /** The Constant FINANCIAL_ID. */
    public static final String FINANCIAL_ID="x-fapi-financial-id";

}
