/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * The Class LoggerUtils.
 */
@Component
public class LoggerUtils {

	/** The req header attribute. */
	@Autowired
	private RequestHeaderAttributes reqHeaderAttribute;

	/** The logger attribute. */
	@Autowired
	private LoggerAttribute loggerAttribute;
	
	/** The api id. */
	@Value("${spring.application.name}")
	private String apiId;

	/**
	 * Populate logger data.
	 *
	 * @return the logger attribute
	 */
	public LoggerAttribute populateLoggerData() {
		loggerAttribute.setApiId(apiId);
		loggerAttribute.setCorrelationId(reqHeaderAttribute.getCorrelationId());
		loggerAttribute.setFinancialId(reqHeaderAttribute.getFinancialId());
		loggerAttribute.setCustomerIPAddress(reqHeaderAttribute.getCustomerIPAddress());
		loggerAttribute.setCustomerLastLoggedTime(reqHeaderAttribute.getCustomerLastLoggedTime());
		loggerAttribute.setRequestId(reqHeaderAttribute.getRequestId());
		loggerAttribute.setTppLegalEntityName(reqHeaderAttribute.getTppLegalEntityName());
		loggerAttribute.setTppCID(reqHeaderAttribute.getTppCID());
		loggerAttribute.setPsuId(reqHeaderAttribute.getPsuId());
		loggerAttribute.setMessage(null);
		return loggerAttribute;
	}

}
