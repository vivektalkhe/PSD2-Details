/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.token;

import org.springframework.data.annotation.Id;

/**
 * The Class AispTokens.
 */
public class AispTokens{

	
	/** The jti. */
	@Id
	private String jti;
	
	/** The token. */
	private String token;
	
	/** The consent id. */
	private String consentId;
	
	/** The status. */
	private String status;
	
	/** The last SCA time stamp. */
	private Long lastSCATimeStamp;
	
	/** The sca valid till. */
	private Long scaValidTill;

	/**
	 * Instantiates a new aisp tokens.
	 */
	public AispTokens() {
		super();
	}

	/**
	 * Instantiates a new aisp tokens.
	 *
	 * @param jti the jti
	 * @param token the token
	 * @param consentId the consent id
	 * @param status the status
	 * @param lastSCATimeStamp the last SCA time stamp
	 * @param scaValidTill the sca valid till
	 */
	public AispTokens(String jti, String token, String consentId,String status,Long lastSCATimeStamp,Long scaValidTill) {
		super();
		this.jti = jti;
		this.token = token;
		this.consentId = consentId;
		this.status = status;
		this.lastSCATimeStamp = lastSCATimeStamp;
		this.scaValidTill = scaValidTill;
	}


	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	
	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	/**
	 * Gets the jti.
	 *
	 * @return the jti
	 */
	public String getJti() {
		return jti;
	}

	/**
	 * Sets the jti.
	 *
	 * @param jti the new jti
	 */
	public void setJti(String jti) {
		this.jti = jti;
	}

	/**
	 * Gets the token.
	 *
	 * @return the token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * Sets the token.
	 *
	 * @param token the new token
	 */
	public void setToken(String token) {
		this.token = token;
	}

	/**
	 * Gets the consent id.
	 *
	 * @return the consent id
	 */
	public String getConsentId() {
		return consentId;
	}

	/**
	 * Sets the consent id.
	 *
	 * @param consentId the new consent id
	 */
	public void setConsentId(String consentId) {
		this.consentId = consentId;
	}

	/**
	 * Gets the sca valid till.
	 *
	 * @return the sca valid till
	 */
	public Long getScaValidTill() {
		return scaValidTill;
	}

	/**
	 * Sets the sca valid till.
	 *
	 * @param scaValidTill the new sca valid till
	 */
	public void setScaValidTill(Long scaValidTill) {
		this.scaValidTill = scaValidTill;
	}

	/**
	 * Gets the last SCA time stamp.
	 *
	 * @return the last SCA time stamp
	 */
	public Long getLastSCATimeStamp() {
		return lastSCATimeStamp;
	}

	/**
	 * Sets the last SCA time stamp.
	 *
	 * @param lastSCATimeStamp the new last SCA time stamp
	 */
	public void setLastSCATimeStamp(Long lastSCATimeStamp) {
		this.lastSCATimeStamp = lastSCATimeStamp;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((jti == null) ? 0 : jti.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AispTokens other = (AispTokens) obj;
		if (jti == null) {
			if (other.jti != null)
				return false;
		} else if (!jti.equals(other.jti))
			return false;
		return true;
	}
}
