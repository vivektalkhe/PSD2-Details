/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.token;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

/**
 * The Class AispTokensTest.
 */
public class AispTokensTest {

	/**
	 * Aisp tokens test.
	 */
	@Test
	public void aispTokensTest() {
		AispTokens aispTokens = new AispTokens();
		aispTokens.setConsentId("05509648");
		aispTokens.setJti("jti");
		aispTokens.setToken("1234xvtaomnao56L1234xvtaomnao56Lasdfjasjashuahdahduh63716237&jjasahs");
		aispTokens.setStatus("Authenticated");
		Long date = 1509348259877L;
		aispTokens.setLastSCATimeStamp(date);
		aispTokens.setScaValidTill(date);
		assertEquals("05509648", aispTokens.getConsentId());
		assertEquals("jti", aispTokens.getJti());
		assertEquals("1234xvtaomnao56L1234xvtaomnao56Lasdfjasjashuahdahduh63716237&jjasahs", aispTokens.getToken());
		assertEquals("Authenticated", aispTokens.getStatus());
		assertEquals(date, aispTokens.getLastSCATimeStamp());
		assertEquals(date, aispTokens.getScaValidTill());
	}

	/**
	 * Aisp tokens hash code test.
	 */
	@Test
	public void aispTokensHashCodeTest() {

		AispTokens aispTokens = new AispTokens();
		aispTokens.setConsentId("05509648");
		aispTokens.setJti("jti");
		aispTokens.setToken("1234xvtaomnao56L1234xvtaomnao56Lasdfjasjashuahdahduh63716237&jjasahs");
		aispTokens.setStatus("Authenticated");
		Long date = 1509348259877L;
		aispTokens.setLastSCATimeStamp(date);
		aispTokens.setScaValidTill(date);

		assertEquals(aispTokens.hashCode(), aispTokens.hashCode());
	}

	/**
	 * Aisp tokens equals test.
	 */
	@Test
	public void aispTokensEqualsTest() {

		AispTokens aispTokens = new AispTokens();
		aispTokens.setConsentId("05509648");
		aispTokens.setJti("jti");
		aispTokens.setToken("1234xvtaomnao56L1234xvtaomnao56Lasdfjasjashuahdahduh63716237&jjasahs");
		aispTokens.setStatus("Authenticated");
		Long date = 1509348259877L;
		aispTokens.setLastSCATimeStamp(date);
		aispTokens.setScaValidTill(date);

		assertEquals(true, aispTokens.equals(aispTokens));
	}

	/**
	 * Aisp tokens constructor test.
	 */
	@Test
	public void aispTokensConstructorTest() {

		// Case#1
		String consentId = "05509648";
		String jti = "jti";
		String token = "1234xvtaomnao56L1234xvtaomnao56Lasdfjasjashuahdahduh63716237&jjasahs";
		String status = "Authenticated";
		Long date = 1509348259877L;

		AispTokens aispTokens = new AispTokens(jti, token, consentId, status, date, date);

		// Case#2
		AispTokens falseToken = null;

		// Case#3
		AispTokens nullJti = new AispTokens(null, token, consentId, status, date, date);

		// Case#4
		AispTokens newJTITokens = new AispTokens("jti1", token, consentId, status, date, date);

		assertEquals(true, aispTokens.equals(aispTokens));
		assertEquals(false, aispTokens.equals(falseToken));
		assertEquals(false, nullJti.equals(aispTokens));
		assertEquals(false, aispTokens.equals(newJTITokens));
	}
}
