/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.token;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

/**
 * The Class TokenTest.
 */
public class TokenTest {

	/**
	 * Test.
	 */
	@Test
	public void test() {
		Token token = new Token(); 
		token.setAccountRequestId("asdafs874-fddf852741");
		token.setBrandId("moneywise");
		token.setChannelId("4b5f9-3a90-4382-a5aa-f0");
		token.setConsentExpiry(1509348259877L);
		token.setConsentId("05509648");
		token.setExp(1509348259877L);
		token.setIat(1509348259877L);
		token.setLastSCADateTime(1509348259877L);
		token.setLastSCADateTime(1509348259877L);
		token.setPsuId("demouser");
		token.setTppCID("moneywise");
		token.setTppLegalEntityName("Moneywise Pvt. Ltd");
		String scope = "accounts";
		List<String> scopes = new ArrayList<>();
		scopes.add(scope);
		token.setScope(scopes);
		token.setJti("jti");
		String role = "accounts";
		List<String> roles = new ArrayList<>();
		roles.add(role);
		token.setRoles(roles);
		Object obj = new Object();
		List<Object> objects = new ArrayList<>();
		objects.add(obj);
		Map<String, List<Object>> claims = new HashMap<>();
		claims.put("claim", objects);
		token.setClaims(claims);
		assertEquals(claims, token.getClaims());
		assertEquals(roles, token.getRoles());
		assertEquals("jti", token.getJti());
		assertEquals(scopes, token.getScope());
		assertEquals("asdafs874-fddf852741", token.getAccountRequestId());
		assertEquals("moneywise", token.getBrandId());
		assertEquals("4b5f9-3a90-4382-a5aa-f0", token.getChannelId());
		assertEquals(1509348259877L, token.getExp());
		assertEquals(1509348259877L, token.getLastSCADateTime());
		assertEquals(1509348259877L, token.getConsentExpiry());
		assertEquals(1509348259877L, token.getIat());
		assertEquals("demouser", token.getPsuId());
		assertEquals("moneywise", token.getTppCID());
		assertEquals("Moneywise Pvt. Ltd", token.getTppLegalEntityName());
		assertEquals("05509648", token.getConsentId());
	}

}
