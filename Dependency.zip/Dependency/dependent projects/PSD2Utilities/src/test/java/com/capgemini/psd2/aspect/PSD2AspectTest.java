/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.aspect;

import static org.mockito.Mockito.when;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.capgemini.psd2.config.PSD2UtilityTestConfig;
import com.capgemini.psd2.exceptions.ErrorCodeEnum;
import com.capgemini.psd2.exceptions.PSD2Exception;
import com.capgemini.psd2.filteration.ResponseFilter;
import com.capgemini.psd2.logger.LoggerAttribute;
import com.capgemini.psd2.logger.LoggerUtils;
import com.capgemini.psd2.logger.RequestHeaderAttributes;
import com.capgemini.psd2.mask.DataMask;


/**
 * The Class PSD2AspectTest.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = PSD2UtilityTestConfig.class)
public class PSD2AspectTest {
	
	/** The data mask. */
	@Mock
	private DataMask dataMask;
	
	/** The logger attribute. */
	@Mock
	private LoggerAttribute loggerAttribute;

	/** The logger utils. */
	@Mock
	private LoggerUtils loggerUtils;

	
	/** The response filter utility. */
	@Mock
	private ResponseFilter responseFilterUtility;
	
	/** The proceeding join point. */
	@Mock
	private ProceedingJoinPoint proceedingJoinPoint;
	
	/** The signature. */
	@Mock
	private MethodSignature signature;
	
	/** The aspect. */
	@InjectMocks
	private PSD2Aspect aspect = new PSD2Aspect();
	
	/** The req header attribute. */
	@Mock
	private RequestHeaderAttributes reqHeaderAttribute;
	
	/**
	 * Before.
	 */
	@Before
	public void before() {
		MockitoAnnotations.initMocks(this);
		
		when(loggerUtils.populateLoggerData()).thenReturn(loggerAttribute);
		when(proceedingJoinPoint.getSignature()).thenReturn(signature);
		when(signature.getName()).thenReturn("retrieveAccountBalance");
		when(signature.getDeclaringTypeName()).thenReturn("retrieveAccountBalance");
		when(proceedingJoinPoint.getArgs()).thenReturn(new Object[1]);
	}

	/**
	 * Arround logger advice controller test.
	 */
	@Test
	public void arroundLoggerAdviceControllerTest() {
		aspect.arroundLoggerAdviceController(proceedingJoinPoint);
	}
	
	/**
	 * Arround logger advice controller masking test.
	 */
	@Test
	public void arroundLoggerAdviceControllerMaskingTest() {
		ReflectionTestUtils.setField(aspect, "payloadLog", true);
		ReflectionTestUtils.setField(aspect, "maskPayloadLog", true);
		ReflectionTestUtils.setField(aspect, "maskPayload", true);
		aspect.arroundLoggerAdviceController(proceedingJoinPoint);
		
		ReflectionTestUtils.setField(aspect, "maskPayloadLog", false);
		aspect.arroundLoggerAdviceController(proceedingJoinPoint);
	}
	
	/**
	 * Arround logger advice service impl test.
	 */
	@Test
	public void arroundLoggerAdviceServiceImplTest() {
		aspect.arroundLoggerAdviceService(proceedingJoinPoint);
	}
	
	/**
	 * Arround logger advice service impl PSD 2 exception failure test.
	 *
	 * @throws Throwable the throwable
	 */
	@Test(expected = PSD2Exception.class)
	public void arroundLoggerAdviceServiceImplPSD2ExceptionFailureTest() throws Throwable{
		when(proceedingJoinPoint.proceed()).thenThrow(PSD2Exception.populatePSD2Exception(ErrorCodeEnum.TECHNICAL_ERROR));
		aspect.arroundLoggerAdviceService(proceedingJoinPoint);
	}
	
	/**
	 * Arround logger advice service impl throwable failure test.
	 *
	 * @throws Throwable the throwable
	 */
	@Test(expected = PSD2Exception.class)
	public void arroundLoggerAdviceServiceImplThrowableFailureTest() throws Throwable{
		when(proceedingJoinPoint.proceed()).thenThrow(new RuntimeException("Test"));
		aspect.arroundLoggerAdviceService(proceedingJoinPoint);
	}
	
	
	/**
	 * Arround logger advice controller throwable failure test.
	 *
	 * @throws Throwable the throwable
	 */
	@Test(expected = PSD2Exception.class)
	public void arroundLoggerAdviceControllerThrowableFailureTest() throws Throwable{
		when(proceedingJoinPoint.proceed()).thenThrow(new RuntimeException("Test"));
		aspect.arroundLoggerAdviceController(proceedingJoinPoint);
	}
	
	/**
	 * Arround logger advice controller PSD 2 exception failure test.
	 *
	 * @throws Throwable the throwable
	 */
	@Test(expected = PSD2Exception.class)
	public void arroundLoggerAdviceControllerPSD2ExceptionFailureTest() throws Throwable{
		when(proceedingJoinPoint.proceed()).thenThrow(PSD2Exception.populatePSD2Exception(ErrorCodeEnum.TECHNICAL_ERROR));
		aspect.arroundLoggerAdviceController(proceedingJoinPoint);
	}
}
