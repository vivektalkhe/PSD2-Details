/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.logger;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.dao.DataAccessResourceFailureException;

import com.capgemini.psd2.token.AispTokens;
import com.capgemini.psd2.token.TokenRepository;

/**
 * The Class PSD2FilterTest.
 */
public class PSD2FilterTest {
	
	/** The http servlet request. */
	@Mock
	private HttpServletRequest httpServletRequest;
	
	/** The request header attributes. */
	@Mock
	private RequestHeaderAttributes requestHeaderAttributes;
	
	/** The http servlet response. */
	@Mock
	private HttpServletResponse httpServletResponse;
	
	/** The filter chain. */
	@Mock
	private FilterChain filterChain;
	
	/** The logger utils. */
	@Mock
	private LoggerUtils loggerUtils;
	
	/** The token repository. */
	@Mock
	private TokenRepository tokenRepository;
	
	/** The aisp token. */
	@Mock
	private AispTokens aispToken;
	
	/** The psd 2 filter. */
	@InjectMocks
	private PSD2Filter psd2Filter = new PSD2Filter();

	/**
	 * Sets the up.
	 *
	 * @throws Exception the exception
	 */
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}
	
	/*@Test
	public void testdoFilterInternal() throws IOException, ServletException {
		Mockito.when(httpServletRequest.getHeader(PSD2Constants.CORRELATION_ID)).thenReturn("ba4f73f8-9a60-425b-aed8-2a7ef2509fea");
		Mockito.when(httpServletRequest.getHeader("Authorization")).thenReturn("Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0cHBJbmZvLWxlZ2FsRW50aXR5TmFtZSI6Ik1vbmV5d2lzZSBQdnQuIEx0ZC4iLCJhdWQiOlsiYmFua0FjY291bnRUcmFuc2FjdGlvbnMiXSwiYmFua0lkIjoiMSIsImNvbnNlbnRJZCI6IjY3MTE4MjkxIiwidHBwSW5mby1yZWdpc3RlcmVkSWQiOiIwMDciLCJ1c2VyX25hbWUiOiJkZW1vdXNlciIsInRwcEluZm8tZGlzcGxhdE5hbWUiOiJNb25leXdpc2UiLCJleHAiOjE0OTEwNDQ3MDcsImF1dGhvcml0aWVzIjpbIlJPTEVfTU9ORVlXSVNFIiwiUk9MRV9DVVNUT01FUlMiXSwianRpIjoiZWUwMzE4NTktYmIxOC00ZWNiLWJmNzAtMTJmYTMzOTYyMDJkIiwiY2xpZW50X2lkIjoibW9uZXl3aXNlIiwidHBwSW5mby10cHBUeXBlIjoiYWlzcCJ9.knD_aMYrmVJzQa8Jc5ypOWoPRU5TCkAEGSdhLOpXfqYLNyqB9QyUfIAb2PfnzZbwTRIsJ7T1rFV5l7779ktVKSv1OGw853J_8y3jUa2jfY7sFVnZxS4PLK17VnzaXUhFXT3L5R2PKSWlGYocLZkOb-BW9Go1L_nTzcx0xsCz5TaOPXh3xih_Bduzo15fu5JGMMVQKaBTd0x_YEtHB25cT57cJnbjrqYObMO0hh6WBkbA8fC4xePan3jyZsyjomVuWOGaS4xJBqhEL_TK5fVng7O1SlLHGkQYzRRrbg7pOL7W2AyJGkMV9BcUgIkKw7L5gPceB1IjL3ug4bPN9DRSXQ");
		Mockito.when(httpServletRequest.getHeader(PSD2Constants.FINANCIAL_ID)).thenReturn("finance123");
		Mockito.when(httpServletRequest.getHeader(PSD2Constants.CUSTOMER_IP_ADDRESS)).thenReturn("10.1.1.2");
		Mockito.when(httpServletRequest.getHeader(PSD2Constants.CUSTOMER_LAST_LOGGED_TIME)).thenReturn("10-10-2017T10:10");
		//String token = "{tppInfo-legalEntityName=Moneywise Pvt. Ltd., aud=[bankAccountTransactions], bankId=1, consentId=67118291, tppInfo-registeredId=007, user_name=demouser, tppInfo-displatName=Moneywise, exp=1491044707, authorities=[ROLE_MONEYWISE, ROLE_CUSTOMERS], jti=ee031859-bb18-4ecb-bf70-12fa3396202d, client_id=moneywise, tppInfo-tppType=aisp}";
		Map tokenMap = new HashMap<>();
		tokenMap.put("jti", "ee031859-bb18-4ecb-bf70-12fa3396202d");
		AispTokens aispTokens = new AispTokens();
		aispTokens.setJti("ee031859-bb18-4ecb-bf70-12fa3396202d");
		//aispTokens.setToken("Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0cHBJbmZvLWxlZ2FsRW50aXR5TmFtZSI6Ik1vbmV5d2lzZSBQdnQuIEx0ZC4iLCJhdWQiOlsiYmFua0FjY291bnRUcmFuc2FjdGlvbnMiXSwiYmFua0lkIjoiMSIsImNvbnNlbnRJZCI6IjY3MTE4MjkxIiwidHBwSW5mby1yZWdpc3RlcmVkSWQiOiIwMDciLCJ1c2VyX25hbWUiOiJkZW1vdXNlciIsInRwcEluZm8tZGlzcGxhdE5hbWUiOiJNb25leXdpc2UiLCJleHAiOjE0OTEwNDQ3MDcsImF1dGhvcml0aWVzIjpbIlJPTEVfTU9ORVlXSVNFIiwiUk9MRV9DVVNUT01FUlMiXSwianRpIjoiZWUwMzE4NTktYmIxOC00ZWNiLWJmNzAtMTJmYTMzOTYyMDJkIiwiY2xpZW50X2lkIjoibW9uZXl3aXNlIiwidHBwSW5mby10cHBUeXBlIjoiYWlzcCJ9.knD_aMYrmVJzQa8Jc5ypOWoPRU5TCkAEGSdhLOpXfqYLNyqB9QyUfIAb2PfnzZbwTRIsJ7T1rFV5l7779ktVKSv1OGw853J_8y3jUa2jfY7sFVnZxS4PLK17VnzaXUhFXT3L5R2PKSWlGYocLZkOb-BW9Go1L_nTzcx0xsCz5TaOPXh3xih_Bduzo15fu5JGMMVQKaBTd0x_YEtHB25cT57cJnbjrqYObMO0hh6WBkbA8fC4xePan3jyZsyjomVuWOGaS4xJBqhEL_TK5fVng7O1SlLHGkQYzRRrbg7pOL7W2AyJGkMV9BcUgIkKw7L5gPceB1IjL3ug4bPN9DRSXQ");
		Mockito.when(tokenRepository.findByJti((String) tokenMap.get("jti"))).thenReturn(aispTokens);
		Token newToken = new Token();
		Map<String, List<Object>> claims = new HashMap<>();
		List<Object> object = new ArrayList<>();
		object.add("ReadAccountsBasic");
		object.add("ReadAccountsDetail");
		object.add("ReadBalances");
		claims.put("accounts", object);
		newToken.setClaims(claims);
		aispTokens.setToken(newToken.toString());
		Mockito.when(aispTokens.getToken()).thenReturn(aispTokens.getToken()); 
		
		psd2Filter.doFilterInternal(httpServletRequest, httpServletResponse, filterChain);		
	}*/
	
	/**
	 * Test.
	 *
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws ServletException the servlet exception
	 */
	@Test 
	public void test() throws IOException, ServletException{
		
		psd2Filter.doFilterInternal(httpServletRequest, httpServletResponse, filterChain);
	}
	
	/**
	 * Testdo filter internal exceptions.
	 *
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws ServletException the servlet exception
	 */
	@Test
	public void testdoFilterInternalExceptions() throws IOException, ServletException {
		Mockito.when(httpServletRequest.getHeader(PSD2Constants.CORRELATION_ID)).thenReturn("ba4f73f8-9a60-425b-aed8-2a7ef2509fea");
		Mockito.when(httpServletRequest.getHeader("Authorization")).thenReturn("Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0cHBJbmZvLWxlZ2FsRW50aXR5TmFtZSI6Ik1vbmV5d2lzZSBQdnQuIEx0ZC4iLCJhdWQiOlsiYmFua0FjY291bnRUcmFuc2FjdGlvbnMiXSwiYmFua0lkIjoiMSIsImNvbnNlbnRJZCI6IjY3MTE4MjkxIiwidHBwSW5mby1yZWdpc3RlcmVkSWQiOiIwMDciLCJ1c2VyX25hbWUiOiJkZW1vdXNlciIsInRwcEluZm8tZGlzcGxhdE5hbWUiOiJNb25leXdpc2UiLCJleHAiOjE0OTEwNDQ3MDcsImF1dGhvcml0aWVzIjpbIlJPTEVfTU9ORVlXSVNFIiwiUk9MRV9DVVNUT01FUlMiXSwianRpIjoiZWUwMzE4NTktYmIxOC00ZWNiLWJmNzAtMTJmYTMzOTYyMDJkIiwiY2xpZW50X2lkIjoibW9uZXl3aXNlIiwidHBwSW5mby10cHBUeXBlIjoiYWlzcCJ9.knD_aMYrmVJzQa8Jc5ypOWoPRU5TCkAEGSdhLOpXfqYLNyqB9QyUfIAb2PfnzZbwTRIsJ7T1rFV5l7779ktVKSv1OGw853J_8y3jUa2jfY7sFVnZxS4PLK17VnzaXUhFXT3L5R2PKSWlGYocLZkOb-BW9Go1L_nTzcx0xsCz5TaOPXh3xih_Bduzo15fu5JGMMVQKaBTd0x_YEtHB25cT57cJnbjrqYObMO0hh6WBkbA8fC4xePan3jyZsyjomVuWOGaS4xJBqhEL_TK5fVng7O1SlLHGkQYzRRrbg7pOL7W2AyJGkMV9BcUgIkKw7L5gPceB1IjL3ug4bPN9DRSXQ");
		Mockito.when(httpServletRequest.getHeader(PSD2Constants.FINANCIAL_ID)).thenReturn("finance123");
		Mockito.when(httpServletRequest.getHeader(PSD2Constants.CUSTOMER_IP_ADDRESS)).thenReturn("10.1.1.2");
		Mockito.when(httpServletRequest.getHeader(PSD2Constants.CUSTOMER_LAST_LOGGED_TIME)).thenReturn("10-10-2017T10:10");
		Mockito.when(httpServletResponse.getWriter()).thenReturn(new PrintWriter("servletResponse"));
		
		
		Map tokenMap = new HashMap<>();
		tokenMap.put("jti", "ee031859-bb18-4ecb-bf70-12fa3396202d");
		
		Mockito.when(tokenRepository.findByJti((String) tokenMap.get("jti"))).thenReturn(null);		
		psd2Filter.doFilterInternal(httpServletRequest, httpServletResponse, filterChain);
		
		Mockito.when(httpServletRequest.getHeader(PSD2Constants.FINANCIAL_ID)).thenReturn("");
		psd2Filter.doFilterInternal(httpServletRequest, httpServletResponse, filterChain);
				
		Mockito.when(tokenRepository.findByJti((String) tokenMap.get("jti"))).thenThrow(new DataAccessResourceFailureException("error"));		
		psd2Filter.doFilterInternal(httpServletRequest, httpServletResponse, filterChain);
	}
	
	/**
	 * Testdo filter internal exceptions 2.
	 *
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws ServletException the servlet exception
	 */
	@Test
	public void testdoFilterInternalExceptions2() throws IOException, ServletException {
		Mockito.when(httpServletRequest.getHeader(PSD2Constants.CORRELATION_ID)).thenReturn("ba4f73f8-9a60-425b-aed8-2a7ef2509fea");
		Mockito.when(httpServletRequest.getHeader("Authorization")).thenReturn("Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0cHBJbmZvLWxlZ2FsRW50aXR5TmFtZSI6Ik1vbmV5d2lzZSBQdnQuIEx0ZC4iLCJhdWQiOlsiYmFua0FjY291bnRUcmFuc2FjdGlvbnMiXSwiYmFua0lkIjoiMSIsImNvbnNlbnRJZCI6IjY3MTE4MjkxIiwidHBwSW5mby1yZWdpc3RlcmVkSWQiOiIwMDciLCJ1c2VyX25hbWUiOiJkZW1vdXNlciIsInRwcEluZm8tZGlzcGxhdE5hbWUiOiJNb25leXdpc2UiLCJleHAiOjE0OTEwNDQ3MDcsImF1dGhvcml0aWVzIjpbIlJPTEVfTU9ORVlXSVNFIiwiUk9MRV9DVVNUT01FUlMiXSwianRpIjoiZWUwMzE4NTktYmIxOC00ZWNiLWJmNzAtMTJmYTMzOTYyMDJkIiwiY2xpZW50X2lkIjoibW9uZXl3aXNlIiwidHBwSW5mby10cHBUeXBlIjoiYWlzcCJ9.knD_aMYrmVJzQa8Jc5ypOWoPRU5TCkAEGSdhLOpXfqYLNyqB9QyUfIAb2PfnzZbwTRIsJ7T1rFV5l7779ktVKSv1OGw853J_8y3jUa2jfY7sFVnZxS4PLK17VnzaXUhFXT3L5R2PKSWlGYocLZkOb-BW9Go1L_nTzcx0xsCz5TaOPXh3xih_Bduzo15fu5JGMMVQKaBTd0x_YEtHB25cT57cJnbjrqYObMO0hh6WBkbA8fC4xePan3jyZsyjomVuWOGaS4xJBqhEL_TK5fVng7O1SlLHGkQYzRRrbg7pOL7W2AyJGkMV9BcUgIkKw7L5gPceB1IjL3ug4bPN9DRSXQ");
		Mockito.when(httpServletRequest.getHeader(PSD2Constants.FINANCIAL_ID)).thenReturn("finance123");
		Mockito.when(httpServletRequest.getHeader(PSD2Constants.CUSTOMER_IP_ADDRESS)).thenReturn("10.1.1.2");
		Mockito.when(httpServletRequest.getHeader(PSD2Constants.CUSTOMER_LAST_LOGGED_TIME)).thenReturn("10-10-2017T10:10");
		Mockito.when(httpServletResponse.getWriter()).thenReturn(new PrintWriter("servletResponse"));
				
		Map tokenMap = new HashMap<>();
		tokenMap.put("jti", "ee031859-bb18-4ecb-bf70-12fa3396202d");		
		
		Mockito.when(tokenRepository.findByJti((String) tokenMap.get("jti"))).thenThrow(new DataAccessResourceFailureException("error"));		
		psd2Filter.doFilterInternal(httpServletRequest, httpServletResponse, filterChain);	
	}

	/**
	 * Tear down.
	 *
	 * @throws Exception the exception
	 */
	@After
	public void tearDown() throws Exception {
		httpServletRequest = null;
		requestHeaderAttributes = null;
		httpServletResponse = null;
		filterChain = null;
		loggerUtils = null;
	}
}
