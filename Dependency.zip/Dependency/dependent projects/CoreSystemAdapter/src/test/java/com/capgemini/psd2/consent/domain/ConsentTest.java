/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.consent.domain;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

/**
 * The Class ConsentTest.
 */
public class ConsentTest {

	/**
	 * Test consent.
	 */
	@Test
	public void testConsent() {
		Consent consent = new Consent();
		consent.setChannelId("Commercial");
		consent.setTppCID("tpp123");
		consent.setPsuId("user123");
		consent.setConsentId("a1e590ad-73dc-453a-841e-2a2ef055e878");
		List<AccountDetails> selectedAccounts = new ArrayList<>();
		AccountDetails accountRequest1 = new AccountDetails();
		accountRequest1.setAccountId("22289");
		accountRequest1.setAccountNSC("SC802001");
		accountRequest1.setAccountNumber("1022675");
		selectedAccounts.add(accountRequest1);
		consent.setAccountDetails(selectedAccounts);

		assertEquals("Commercial", consent.getChannelId());
		assertEquals("tpp123", consent.getTppCID());
		assertEquals("user123", consent.getPsuId());
		assertEquals("a1e590ad-73dc-453a-841e-2a2ef055e878", consent.getConsentId());
		assertEquals(selectedAccounts, consent.getAccountDetails());
	}

}
