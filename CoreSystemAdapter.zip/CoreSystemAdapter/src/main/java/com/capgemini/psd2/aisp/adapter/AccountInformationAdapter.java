package com.capgemini.psd2.aisp.adapter;

import java.util.Map;

import com.capgemini.psd2.aisp.domain.AccountGETResponse;
import com.capgemini.psd2.aisp.domain.AccountMapping;

public interface AccountInformationAdapter {
	public AccountGETResponse retrieveAccountInformation(AccountMapping accountMapping, Map<String, String> params);
	public AccountGETResponse retrieveAccountInformations(AccountMapping accountMapping, Map<String, String> params);
}
