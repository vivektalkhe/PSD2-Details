package com.capgemini.psd2.aisp.transformer;

import java.util.Map;

import com.capgemini.psd2.aisp.domain.AccountGETResponse;

public interface AccountInformationTransformer {
	public <T> AccountGETResponse transformAccountInformation(T source, AccountGETResponse destination, Map<String, String> params);
	public <T> AccountGETResponse transformAccountInformations(T source, AccountGETResponse destination, Map<String, String> params);
}
