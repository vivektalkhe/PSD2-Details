package com.capgemini.psd2.aisp.transformer;

import java.util.Map;

import com.capgemini.psd2.aisp.domain.AccountTransactionsGETResponse;

public interface AcountTransactionTransformer {
	public <T> AccountTransactionsGETResponse transformAccountTransaction(T source, AccountTransactionsGETResponse destination, Map<String, String> params);
	public <T> AccountTransactionsGETResponse transformAccountTransactions(T source, AccountTransactionsGETResponse destination, Map<String, String> params); 
}
