package com.capgemini.psd2.aisp.transformer;

import java.util.Map;

import com.capgemini.psd2.aisp.domain.Consent;

public interface ConsentMappingTransformer {
	public <T> Consent transformConsent(T source, Consent destination, Map<String, String> params);
}
