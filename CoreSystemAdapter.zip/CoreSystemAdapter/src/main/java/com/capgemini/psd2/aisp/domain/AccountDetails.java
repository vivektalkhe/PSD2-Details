package com.capgemini.psd2.aisp.domain;

import com.google.gson.annotations.SerializedName;

public class AccountDetails {
	
	@SerializedName("AccountNumber")
	public String accountNumber;
	
	@SerializedName("AccountNSC")
	public String accountNSC;
	
	@SerializedName("AccountId")
	public String accountId;

	/**
	 * @return the accountNumber
	 */
	public String getAccountNumber() {
		return accountNumber;
	}

	/**
	 * @param accountNumber
	 *            the accountNumber to set
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
	 * @return the accountNSC
	 */
	public String getAccountNSC() {
		return accountNSC;
	}

	/**
	 * @param accountNSC
	 *            the accountNSC to set
	 */
	public void setAccountNSC(String accountNSC) {
		this.accountNSC = accountNSC;
	}

	/**
	 * @return the accountId
	 */
	public String getAccountId() {
		return accountId;
	}

	/**
	 * @param accountId
	 *            the accountId to set
	 */
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

}
