package com.capgemini.psd2.aisp.adapter;

import java.util.Map;

import com.capgemini.psd2.aisp.domain.AccountMapping;
import com.capgemini.psd2.aisp.domain.BalancesGETResponse;

public interface AccountBalanceAdapter {
	public BalancesGETResponse retrieveAccountBalance(AccountMapping accountMapping, Map<String, String> params);
	public BalancesGETResponse retrieveAccountBalances(AccountMapping accountMapping, Map<String, String> params); 
}
