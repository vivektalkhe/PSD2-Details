package com.capgemini.psd2.aisp.domain;

public class Consent {

}
