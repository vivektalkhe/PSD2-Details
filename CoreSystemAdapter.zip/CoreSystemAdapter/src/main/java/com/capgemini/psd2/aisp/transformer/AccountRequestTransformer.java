package com.capgemini.psd2.aisp.transformer;

import java.util.Map;

import com.capgemini.psd2.aisp.domain.AccountRequestPOSTResponse;

public interface AccountRequestTransformer {
	
	public <T> AccountRequestPOSTResponse transformAccountInformation(T source, AccountRequestPOSTResponse destination,
			Map<String, String> params);

}
