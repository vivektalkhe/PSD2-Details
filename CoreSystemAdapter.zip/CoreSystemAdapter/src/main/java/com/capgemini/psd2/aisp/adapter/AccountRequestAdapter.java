package com.capgemini.psd2.aisp.adapter;

import java.util.Map;

import com.capgemini.psd2.aisp.domain.AccountRequestPOSTResponse;

public interface AccountRequestAdapter {

	public AccountRequestPOSTResponse insertAccountRequestPOSTResponse(String bankId,
			AccountRequestPOSTResponse accountRequestPOSTResponse, Map<String, String> params);
}
