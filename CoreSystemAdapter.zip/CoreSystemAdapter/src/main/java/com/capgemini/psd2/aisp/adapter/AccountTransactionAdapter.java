package com.capgemini.psd2.aisp.adapter;

import java.util.Map;

import com.capgemini.psd2.aisp.domain.AccountMapping;
import com.capgemini.psd2.aisp.domain.AccountTransactionsGETResponse;

public interface AccountTransactionAdapter {
	public AccountTransactionsGETResponse retrieveAccountTransaction( AccountMapping accountMapping, Map<String, String> params);
	public AccountTransactionsGETResponse retrieveAccountTransactions( AccountMapping accountMapping, Map<String, String> params); 
}
