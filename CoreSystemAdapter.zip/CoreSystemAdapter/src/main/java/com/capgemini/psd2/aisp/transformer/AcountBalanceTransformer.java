package com.capgemini.psd2.aisp.transformer;

import java.util.Map;

import com.capgemini.psd2.aisp.domain.BalancesGETResponse;

public interface AcountBalanceTransformer {
	public <T> BalancesGETResponse transformAccountBalance(T source, BalancesGETResponse destination, Map<String, String> params);
	public <T> BalancesGETResponse transfromAccountBalances(T source, BalancesGETResponse destination, Map<String, String> params); 
}
