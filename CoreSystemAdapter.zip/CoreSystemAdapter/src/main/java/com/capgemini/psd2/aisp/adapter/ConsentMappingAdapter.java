package com.capgemini.psd2.aisp.adapter;

import com.capgemini.psd2.aisp.domain.Consent;

public interface ConsentMappingAdapter {
	public Consent retrieveConsent(String accountRequestId);
}
