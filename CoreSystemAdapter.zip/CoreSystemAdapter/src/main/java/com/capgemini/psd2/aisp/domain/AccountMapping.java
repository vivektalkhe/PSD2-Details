package com.capgemini.psd2.aisp.domain;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class AccountMapping {

	@SerializedName("PsuId")
	public String psuId;
	
	@SerializedName("TppCID")
	public String tppCId;
	
	@SerializedName("ChannelId")
	public String channelId;
	
	@SerializedName("AccountDetails")
	public List<AccountDetails> accountDetails;

	/**
	 * @return the psuId
	 */
	public String getPsuId() {
		return psuId;
	}

	/**
	 * @param psuId the psuId to set
	 */
	public void setPsuId(String psuId) {
		this.psuId = psuId;
	}

	/**
	 * @return the tppCId
	 */
	public String getTppCId() {
		return tppCId;
	}

	/**
	 * @param tppCId the tppCId to set
	 */
	public void setTppCId(String tppCId) {
		this.tppCId = tppCId;
	}

	/**
	 * @return the channelId
	 */
	public String getChannelId() {
		return channelId;
	}

	/**
	 * @param channelId the channelId to set
	 */
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	/**
	 * @return the accountDetails
	 */
	public List<AccountDetails> getAccountDetails() {
		return accountDetails;
	}

	/**
	 * @param accountDetails the accountDetails to set
	 */
	public void setAccountDetails(List<AccountDetails> accountDetails) {
		this.accountDetails = accountDetails;
	}

	
}
