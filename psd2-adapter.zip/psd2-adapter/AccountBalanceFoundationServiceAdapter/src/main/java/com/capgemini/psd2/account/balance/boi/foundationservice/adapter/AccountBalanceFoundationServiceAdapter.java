/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.account.balance.boi.foundationservice.adapter;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import com.capgemini.psd2.account.balance.boi.foundationservice.constants.AccountBalanceFoundationServiceConstants;
import com.capgemini.psd2.account.balance.boi.foundationservice.delegate.AccountBalanceFoundationServiceDelegate;
import com.capgemini.psd2.account.balance.boi.foundationservice.domain.Accounts;
import com.capgemini.psd2.adapter.exceptions.AdapterErrorCodeEnum;
import com.capgemini.psd2.adapter.exceptions.AdapterException;
import com.capgemini.psd2.aisp.adapter.AccountBalanceAdapter;
import com.capgemini.psd2.aisp.domain.BalancesGETResponse;
import com.capgemini.psd2.consent.domain.AccountDetails;
import com.capgemini.psd2.consent.domain.AccountMapping;
import com.capgemini.psd2.rest.client.model.RequestInfo;
import com.capgemini.psd2.utilities.NullCheckUtils;

/**
 * The Class AccountBalanceFoundationServiceAdapter.
 */
@Component
public class AccountBalanceFoundationServiceAdapter implements AccountBalanceAdapter {

	/** The single account balance base URL. */
	@Value("${foundationService.singleAccountBalanceBaseURL}")
	private String singleAccountBalanceBaseURL;

	/** The account balance foundation service delegate. */
	@Autowired
	private AccountBalanceFoundationServiceDelegate accountBalanceFoundationServiceDelegate;

	/* (non-Javadoc)
	 * @see com.capgemini.psd2.aisp.adapter.AccountBalanceAdapter#retrieveAccountBalance(com.capgemini.psd2.consent.domain.AccountMapping, java.util.Map)
	 */
	@Override
	public BalancesGETResponse retrieveAccountBalance(AccountMapping accountMapping, Map<String, String> params) {

		RequestInfo requestInfo = new RequestInfo();
		HttpHeaders httpHeaders = accountBalanceFoundationServiceDelegate.createRequestHeaders(requestInfo,	accountMapping);

		AccountDetails accountDetails;
		if (accountMapping != null && accountMapping.getAccountDetails() != null && !accountMapping.getAccountDetails().isEmpty()) {
			accountDetails = accountMapping.getAccountDetails().get(0);
			if(params == null)
				params = new HashMap<>();
			params.put(AccountBalanceFoundationServiceConstants.ACCOUNT_ID, accountDetails.getAccountId());

		} else
			throw AdapterException.populatePSD2Exception(AdapterErrorCodeEnum.NO_ACCOUNT_DATA_FOUND);

		String finalURL = accountBalanceFoundationServiceDelegate.getFoundationServiceURL(accountDetails.getAccountNSC(), accountDetails.getAccountNumber(), singleAccountBalanceBaseURL);
		requestInfo.setUrl(finalURL);

		Accounts accounts = accountBalanceFoundationServiceDelegate.restTransportForSingleAccountBalance(requestInfo, Accounts.class, httpHeaders);
		if(NullCheckUtils.isNullOrEmpty(accounts)) {
			throw AdapterException.populatePSD2Exception(AdapterErrorCodeEnum.NO_ACCOUNT_DATA_FOUND_FOUNDATION_SERVICE);
		}
		return accountBalanceFoundationServiceDelegate.transformResponseFromFDToAPI(accounts, params);

	}

}
