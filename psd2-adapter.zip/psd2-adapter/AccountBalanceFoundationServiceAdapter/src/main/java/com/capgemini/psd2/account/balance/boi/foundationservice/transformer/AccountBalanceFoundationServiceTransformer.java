/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.account.balance.boi.foundationservice.transformer;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capgemini.psd2.account.balance.boi.foundationservice.constants.AccountBalanceFoundationServiceConstants;
import com.capgemini.psd2.account.balance.boi.foundationservice.domain.Accnt;
import com.capgemini.psd2.account.balance.boi.foundationservice.domain.Accounts;
import com.capgemini.psd2.account.balance.boi.foundationservice.validations.AccountBalanceValidator;
import com.capgemini.psd2.adapter.exceptions.AdapterErrorCodeEnum;
import com.capgemini.psd2.adapter.exceptions.AdapterException;
import com.capgemini.psd2.aisp.domain.BalancesGETResponse;
import com.capgemini.psd2.aisp.domain.BalancesGETResponseAmount;
import com.capgemini.psd2.aisp.domain.BalancesGETResponseData;
import com.capgemini.psd2.aisp.domain.BalancesGETResponseData.CreditDebitIndicatorEnum;
import com.capgemini.psd2.aisp.domain.BalancesGETResponseData.TypeEnum;
import com.capgemini.psd2.aisp.transformer.AcountBalanceTransformer;

/**
 * The Class AccountBalanceFoundationServiceTransformer.
 */
@Component
public class AccountBalanceFoundationServiceTransformer implements AcountBalanceTransformer {
	
	/** The account balance validator. */
	@Autowired
	private AccountBalanceValidator accountBalanceValidator;

	/* (non-Javadoc)
	 * @see com.capgemini.psd2.aisp.transformer.AcountBalanceTransformer#transformAccountBalance(java.lang.Object, java.util.Map)
	 */
	@Override
	public <T> BalancesGETResponse transformAccountBalance(T inputBalanceObj, Map<String, String> params) {
		Accounts accounts = (Accounts) inputBalanceObj;
		BalancesGETResponse balancesGETResponse = new BalancesGETResponse();
		for(Accnt accnt: accounts.getAccount()) {
			BalancesGETResponseData responseDataObj = new BalancesGETResponseData();
			BalancesGETResponseAmount amount = new BalancesGETResponseAmount();
			String resAmount = new DecimalFormat("0.00000").format(accnt.getBalance().getPostedBalance());
			String currency = accnt.getBalance().getCurrency();
			if(!accountBalanceValidator.validateAccountId(params.get(AccountBalanceFoundationServiceConstants.ACCOUNT_ID))) {
				throw AdapterException.populatePSD2Exception(AdapterErrorCodeEnum.NO_ACCOUNT_ID_FOUND);
			}
			if(!accountBalanceValidator.validateAmount(resAmount)) {
				throw AdapterException.populatePSD2Exception(AdapterErrorCodeEnum.INVALID_AMOUNT);
			}
			if(!accountBalanceValidator.validateCurrency(currency)) {
				throw AdapterException.populatePSD2Exception(AdapterErrorCodeEnum.INVALID_CURRENCY);
			}
			amount.setAmount(resAmount);
			amount.setCurrency(currency);
			if(accnt.getBalance().getPostedBalance().compareTo(BigDecimal.ZERO)==0 || accnt.getBalance().getPostedBalance().compareTo(BigDecimal.ZERO) > 0)
				responseDataObj.setCreditDebitIndicator(CreditDebitIndicatorEnum.CREDIT);
			else
				responseDataObj.setCreditDebitIndicator(CreditDebitIndicatorEnum.DEBIT);
			responseDataObj.setAccountId(params.get(AccountBalanceFoundationServiceConstants.ACCOUNT_ID));
			responseDataObj.type(TypeEnum.EXPECTED);
			responseDataObj.setAmount(amount);
			responseDataObj.setDateTime(LocalDateTime.now().toString());
			balancesGETResponse.getData().add(responseDataObj);
		}
		return balancesGETResponse;
	}

}
