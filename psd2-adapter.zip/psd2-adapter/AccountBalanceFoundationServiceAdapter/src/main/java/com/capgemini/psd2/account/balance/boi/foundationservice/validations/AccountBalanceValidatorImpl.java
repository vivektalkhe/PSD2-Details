/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.account.balance.boi.foundationservice.validations;

import org.springframework.stereotype.Component;

import com.capgemini.psd2.account.balance.boi.foundationservice.constants.AccountBalanceFoundationServiceConstants;
import com.capgemini.psd2.utilities.NullCheckUtils;

/**
 * The Class AccountBalanceValidatorImpl.
 */
@Component
public class AccountBalanceValidatorImpl implements AccountBalanceValidator{
	
	/* (non-Javadoc)
	 * @see com.capgemini.psd2.account.balance.boi.foundationservice.validations.AccountBalanceValidator#validateAmount(java.lang.String)
	 */
	@Override
	public boolean validateAmount(String amount) {
	    return amount.matches(AccountBalanceFoundationServiceConstants.AMOUNT_REGEX);
	}
	
	/* (non-Javadoc)
	 * @see com.capgemini.psd2.account.balance.boi.foundationservice.validations.AccountBalanceValidator#validateCurrency(java.lang.String)
	 */
	@Override
	public boolean validateCurrency(String currency) {
		return currency.matches(AccountBalanceFoundationServiceConstants.CURRENCY_REGEX);
	}
	
	/* (non-Javadoc)
	 * @see com.capgemini.psd2.account.balance.boi.foundationservice.validations.AccountBalanceValidator#validateAccountId(java.lang.String)
	 */
	@Override
	public boolean validateAccountId(String accountId) {
		if(NullCheckUtils.isNullOrEmpty(accountId) || accountId.length() >40) {
			return false;
		}
		return true;
	}

}
