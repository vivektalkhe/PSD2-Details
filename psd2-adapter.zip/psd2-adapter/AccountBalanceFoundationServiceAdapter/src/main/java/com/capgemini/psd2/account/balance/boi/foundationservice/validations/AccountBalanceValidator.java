/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.account.balance.boi.foundationservice.validations;

/**
 * The Interface AccountBalanceValidator.
 */
public interface AccountBalanceValidator {
	
	/**
	 * Validate amount.
	 *
	 * @param amount the amount
	 * @return true, if successful
	 */
	public boolean validateAmount(String amount);
	
	/**
	 * Validate currency.
	 *
	 * @param currency the currency
	 * @return true, if successful
	 */
	public boolean validateCurrency(String currency);
	
	/**
	 * Validate account id.
	 *
	 * @param accountId the account id
	 * @return true, if successful
	 */
	public boolean validateAccountId(String accountId);
}
