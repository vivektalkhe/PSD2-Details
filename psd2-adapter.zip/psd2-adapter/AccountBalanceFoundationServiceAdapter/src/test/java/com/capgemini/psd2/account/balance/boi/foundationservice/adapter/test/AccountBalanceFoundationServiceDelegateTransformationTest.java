/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.account.balance.boi.foundationservice.adapter.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.capgemini.psd2.account.balance.boi.foundationservice.config.test.AccountBalanceFoundationServiceAdapterTestConfiguration;
import com.capgemini.psd2.account.balance.boi.foundationservice.domain.Accnt;
import com.capgemini.psd2.account.balance.boi.foundationservice.domain.Accounts;
import com.capgemini.psd2.account.balance.boi.foundationservice.domain.Balance;
import com.capgemini.psd2.account.balance.boi.foundationservice.transformer.AccountBalanceFoundationServiceTransformer;
import com.capgemini.psd2.account.balance.boi.foundationservice.validations.AccountBalanceValidator;
import com.capgemini.psd2.account.balance.boi.foundationservice.validations.AccountBalanceValidatorImpl;
import com.capgemini.psd2.aisp.domain.BalancesGETResponse;
import com.capgemini.psd2.aisp.domain.BalancesGETResponseAmount;
import com.capgemini.psd2.aisp.domain.BalancesGETResponseData;
import com.capgemini.psd2.aisp.domain.BalancesGETResponseData.TypeEnum;
import com.capgemini.psd2.rest.client.sync.impl.RestClientSyncImpl;

/**
 * The Class AccountBalanceFoundationServiceDelegateTransformationTest.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes=AccountBalanceFoundationServiceAdapterTestConfiguration.class)
public class AccountBalanceFoundationServiceDelegateTransformationTest {
	
	/** The account balance FS transformer. */
	@InjectMocks
	private AccountBalanceFoundationServiceTransformer accountBalanceFSTransformer=new AccountBalanceFoundationServiceTransformer();
	
	/** The account balance validator. */
	@Spy
	private AccountBalanceValidator accountBalanceValidator = new AccountBalanceValidatorImpl();
	
	/** The rest client. */
	@Mock
	private RestClientSyncImpl restClient;
	
	/**
	 * Sets the up.
	 */
	@Before
	public void setUp(){
		MockitoAnnotations.initMocks(this);
	}
	
	/**
	 * Context loads.
	 */
	@Test
	public void contextLoads() {
	}
	
	/**
	 * Test transform response from FD to API.
	 */
	@Test
	public void testTransformResponseFromFDToAPI() {
		
		Map<String, String> params = new HashMap<>();
		params.put("accountId", "12345");
		Balance bal = new Balance();
		bal.setAvailableBalance(new BigDecimal(5000.00d));
		bal.setCurrency("GBP");
		bal.setPostedBalance(new BigDecimal(5000.00d));
		Accounts accounts = new Accounts();
		Accnt accnt = new Accnt();
		accnt.setBalance(bal);
		accounts.getAccount().add(accnt);
		
		BalancesGETResponse finalGBResponseObj = new BalancesGETResponse();
		BalancesGETResponseAmount amount = new BalancesGETResponseAmount();
		amount.setAmount(new BigDecimal(5000.00d).toString());
		amount.setCurrency("GBP");
		BalancesGETResponseData responseDataObj = new BalancesGETResponseData();
		responseDataObj.setAccountId(params.get("accountId"));
		responseDataObj.type(TypeEnum.CLOSINGBOOKED);
		responseDataObj.setAmount(amount);
		finalGBResponseObj.getData().add(responseDataObj);
		
		BalancesGETResponse res = accountBalanceFSTransformer.transformAccountBalance(accounts, params);
		assertNotNull(res);
		assertEquals("Test for transformation failed.","5000.00000", res.getData().get(0).getAmount().getAmount());
	}
	
}
