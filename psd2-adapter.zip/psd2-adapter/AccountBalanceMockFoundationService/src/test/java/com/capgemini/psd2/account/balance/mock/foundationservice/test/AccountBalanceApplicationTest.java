package com.capgemini.psd2.account.balance.mock.foundationservice.test;

import org.junit.Test;


/**
 * The Class AccountBalanceApplicationTest.
 */
public class AccountBalanceApplicationTest {

	/**
	 * Context loads.
	 */
	@Test
	public void contextLoads() {
	}
	
}
