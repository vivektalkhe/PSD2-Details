/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.account.balance.mock.foundationservice;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.capgemini.psd2.account.balance.mock.foundationservice.domain.Accnt;
import com.capgemini.psd2.account.balance.mock.foundationservice.domain.Balance;
import com.capgemini.psd2.account.balance.mock.foundationservice.repository.AccountBalanceRepository;

/**
 * The Class AccountBalanceApplication.
 */
@EnableMongoRepositories(basePackages = { "com.capgemini.psd2" })
@SpringBootApplication
@ComponentScan(basePackages = { "com.capgemini.psd2" })
public class AccountBalanceApplication implements CommandLineRunner  {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 * 
	 */
	
	@Autowired
	private AccountBalanceRepository repository;
	
	public static void main(String[] args) {
		SpringApplication.run(AccountBalanceApplication.class, args);
 }

	@Override
	public void run(String... arg0) throws Exception {
	
		Accnt account = new Accnt();
		account.setNsc("nscVv1");
		account.setAccountNumber("acctVv1");
		account.setCreditCardNumber("123456Vv1xxx");
		
		Balance b = new Balance();
		b.setAvailableBalance(BigDecimal.valueOf(300.00));
		b.setPostedBalance(BigDecimal.valueOf(300.00));
		b.setCurrency("EUR");		
		account.setBalance(b);
		
		repository.save(account);
		
		
		
	}
}
