/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.account.information.boi.foundationservice.delegate;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import com.capgemini.psd2.account.information.boi.foundationservice.constants.AccountInformationFoundationServiceConstants;
import com.capgemini.psd2.account.information.boi.foundationservice.domain.Accnt;
import com.capgemini.psd2.account.information.boi.foundationservice.domain.Accounts;
import com.capgemini.psd2.account.information.boi.foundationservice.transformer.AccountInformationFoundationServiceTransformer;
import com.capgemini.psd2.adapter.exceptions.AdapterErrorCodeEnum;
import com.capgemini.psd2.adapter.exceptions.AdapterException;
import com.capgemini.psd2.aisp.domain.AccountGETResponse;
import com.capgemini.psd2.consent.domain.AccountMapping;
import com.capgemini.psd2.rest.client.model.RequestInfo;
import com.capgemini.psd2.rest.client.sync.RestClientSync;
import com.capgemini.psd2.utilities.NullCheckUtils;

/**
 * The Class AccountInformationFoundationServiceDelegate.
 */
@Component
public class AccountInformationFoundationServiceDelegate {

	/** The rest client. */
	@Autowired
	@Qualifier("restClientFoundation")
	private RestClientSync restClient;
	
	/** The env. */
	@Autowired
	private Environment env;
	
	/** The account information FS transformer. */
	@Autowired
	AccountInformationFoundationServiceTransformer accountInformationFSTransformer;

	/** The user in req header. */
	@Value("${foundationService.userInReqHeader:#{X-BOI-USER}}")
	private String userInReqHeader;

	/** The channel in req header. */
	@Value("${foundationService.channelInReqHeader:#{X-BOI-CHANNEL}}")
	private String channelInReqHeader;

	/** The platform in req header. */
	@Value("${foundationService.platformInReqHeader:#{X-BOI-PLATFORM}}")
	private String platformInReqHeader;

	/** The correlation id in req header. */
	@Value("${foundationService.correlationIdInReqHeader:#{X-CORRELATION-ID}}")
	private String correlationIdInReqHeader;
	
	/** The platform. */
	@Value("${app.platform}")
	private String platform;

	/**
	 * Rest transport for single account information.
	 *
	 * @param reqInfo the req info
	 * @param responseType the response type
	 * @param headers the headers
	 * @return the accounts
	 */
	public Accounts restTransportForSingleAccountInformation(RequestInfo reqInfo, Class<Accounts> responseType,
			HttpHeaders headers) {
		return restClient.callForGet(reqInfo, responseType, headers);

	}

	/**
	 * Gets the foundation service URL.
	 *
	 * @param channelId the channel id
	 * @param accountNSC the account NSC
	 * @param accountNumber the account number
	 * @return the foundation service URL
	 */
	public String getFoundationServiceURL(String channelId, String accountNSC, String accountNumber) {
		if(NullCheckUtils.isNullOrEmpty(channelId)) {
			throw AdapterException.populatePSD2Exception(AdapterErrorCodeEnum.NO_CHANNEL_ID_IN_REQUEST);
		}
		if(NullCheckUtils.isNullOrEmpty(accountNSC)) {
			throw AdapterException.populatePSD2Exception(AdapterErrorCodeEnum.NO_ACCOUNT_NSC_IN_REQUEST);
		}
		if(NullCheckUtils.isNullOrEmpty(accountNumber)) {
			throw AdapterException.populatePSD2Exception(AdapterErrorCodeEnum.NO_ACCOUNT_DATA_FOUND);
		}
		channelId = channelId.toUpperCase();
		String baseURL = env.getProperty(AccountInformationFoundationServiceConstants.FOUNDATION_SERVICE+"."+channelId+"."+AccountInformationFoundationServiceConstants.BASE_URL);
		if(NullCheckUtils.isNullOrEmpty(baseURL)) {
			throw AdapterException.populatePSD2Exception(AdapterErrorCodeEnum.NO_ACCOUNT_DATA_FOUND);
		}
		return baseURL + "/" + accountNSC + "/" + accountNumber + "/" + "account";
	}

	/**
	 * Transform response from FD to API.
	 *
	 * @param accnt the accnt
	 * @param params the params
	 * @return the account GET response
	 */
	public AccountGETResponse transformResponseFromFDToAPI(Accnt accnt, Map<String, String> params) {
		return accountInformationFSTransformer.transformAccountInformation(accnt, params);
	}

	/**
	 * Gets the account from account list.
	 *
	 * @param accountNumber the account number
	 * @param accounts the accounts
	 * @return the account from account list
	 */
	public Accnt getAccountFromAccountList(String accountNumber, Accounts accounts) {
		for (Accnt account : accounts.getAccount()) {
			if (account.getAccountNumber().equalsIgnoreCase(accountNumber)) {
				return account;
			}
		}
		return null;
	}

	/**
	 * Creates the request headers.
	 *
	 * @param requestInfo the request info
	 * @param accountMapping the account mapping
	 * @return the http headers
	 */
	public HttpHeaders createRequestHeaders(RequestInfo requestInfo, AccountMapping accountMapping) {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add(userInReqHeader, accountMapping.getPsuId());
		httpHeaders.add(channelInReqHeader, accountMapping.getChannelId());
		httpHeaders.add(platformInReqHeader, platform);
		httpHeaders.add(correlationIdInReqHeader, accountMapping.getCorrelationId());
		return httpHeaders;
	}
}
