/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.account.information.boi.foundationservice.adapter;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import com.capgemini.psd2.account.information.boi.foundationservice.constants.AccountInformationFoundationServiceConstants;
import com.capgemini.psd2.account.information.boi.foundationservice.delegate.AccountInformationFoundationServiceDelegate;
import com.capgemini.psd2.account.information.boi.foundationservice.domain.Accnt;
import com.capgemini.psd2.account.information.boi.foundationservice.domain.Accounts;
import com.capgemini.psd2.adapter.exceptions.AdapterErrorCodeEnum;
import com.capgemini.psd2.adapter.exceptions.AdapterException;
import com.capgemini.psd2.aisp.adapter.AccountInformationAdapter;
import com.capgemini.psd2.aisp.domain.AccountGETResponse;
import com.capgemini.psd2.consent.domain.AccountDetails;
import com.capgemini.psd2.consent.domain.AccountMapping;
import com.capgemini.psd2.rest.client.model.RequestInfo;
import com.capgemini.psd2.utilities.NullCheckUtils;

/**
 * The Class AccountInformationFoundationServiceAdapter.
 */
@Component
public class AccountInformationFoundationServiceAdapter implements AccountInformationAdapter {

	/** The account information foundation service delegate. */
	@Autowired
	private AccountInformationFoundationServiceDelegate accountInformationFoundationServiceDelegate;

	/* (non-Javadoc)
	 * @see com.capgemini.psd2.aisp.adapter.AccountInformationAdapter#retrieveAccountInformation(com.capgemini.psd2.consent.domain.AccountMapping, java.util.Map)
	 */
	@Override
	public AccountGETResponse retrieveAccountInformation(AccountMapping accountMapping, Map<String, String> params) {
		RequestInfo requestInfo = new RequestInfo();
		HttpHeaders httpHeaders = accountInformationFoundationServiceDelegate.createRequestHeaders(requestInfo,
				accountMapping);
		AccountDetails accountDetails;
		if (accountMapping != null && accountMapping.getAccountDetails() != null && !accountMapping.getAccountDetails().isEmpty()) {
			accountDetails = accountMapping.getAccountDetails().get(0);
			if(params == null)
				params = new HashMap<>();
			params.put(AccountInformationFoundationServiceConstants.ACCOUNT_ID, accountDetails.getAccountId());
		} else
			throw AdapterException.populatePSD2Exception(AdapterErrorCodeEnum.NO_ACCOUNT_DATA_FOUND);
		String finalURL = accountInformationFoundationServiceDelegate
				.getFoundationServiceURL(accountMapping.getChannelId(), accountDetails.getAccountNSC(), accountDetails.getAccountNumber());
		requestInfo.setUrl(finalURL);
		Accounts accounts = accountInformationFoundationServiceDelegate
				.restTransportForSingleAccountInformation(requestInfo, Accounts.class, httpHeaders);
		if(NullCheckUtils.isNullOrEmpty(accounts)) {
			throw AdapterException.populatePSD2Exception(AdapterErrorCodeEnum.NO_ACCOUNT_DATA_FOUND_FOUNDATION_SERVICE);
		}
		Accnt accnt = accountInformationFoundationServiceDelegate
				.getAccountFromAccountList(accountDetails.getAccountNumber(), accounts);
		if(NullCheckUtils.isNullOrEmpty(accnt)) {
			throw AdapterException.populatePSD2Exception(AdapterErrorCodeEnum.NO_ACCOUNT_DATA_FOUND_FOUNDATION_SERVICE);
		}
		return accountInformationFoundationServiceDelegate.transformResponseFromFDToAPI(accnt, params);
	}


}
