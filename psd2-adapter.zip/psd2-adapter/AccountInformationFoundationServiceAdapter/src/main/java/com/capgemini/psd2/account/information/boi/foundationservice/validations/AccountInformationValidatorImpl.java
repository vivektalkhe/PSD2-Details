/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.account.information.boi.foundationservice.validations;

import org.springframework.stereotype.Component;
import com.capgemini.psd2.account.information.boi.foundationservice.constants.AccountInformationFoundationServiceConstants;
import com.capgemini.psd2.utilities.NullCheckUtils;

/**
 * The Class AccountInformationValidatorImpl.
 */
@Component
public class AccountInformationValidatorImpl implements AccountInformationValidator {
	
	/* (non-Javadoc)
	 * @see com.capgemini.psd2.account.information.boi.foundationservice.validations.AccountInformationValidator#validateCurrency(java.lang.String)
	 */
	@Override
	public boolean validateCurrency(String currency) {
		if(NullCheckUtils.isNullOrEmpty(currency)) {
			return false;
		}
		return currency.matches(AccountInformationFoundationServiceConstants.CURRENCY_REGEX);
	}

	/* (non-Javadoc)
	 * @see com.capgemini.psd2.account.information.boi.foundationservice.validations.AccountInformationValidator#validateAccountId(java.lang.String)
	 */
	@Override
	public boolean validateAccountId(String accountId) {
		if(NullCheckUtils.isNullOrEmpty(accountId) || accountId.length() >40) {
			return false;
		}
		return true;
	}


	/* (non-Javadoc)
	 * @see com.capgemini.psd2.account.information.boi.foundationservice.validations.AccountInformationValidator#validateNickName(java.lang.String)
	 */
	@Override
	public boolean validateNickName(String nickName) {
		if(NullCheckUtils.isNullOrEmpty(nickName) || nickName.length() >70) {
			return false;
		}
		return true;
	}
	
	/* (non-Javadoc)
	 * @see com.capgemini.psd2.account.information.boi.foundationservice.validations.AccountInformationValidator#validateIdentification(java.lang.String)
	 */
	@Override
	public boolean validateIdentification(String identification) {
		if(NullCheckUtils.isNullOrEmpty(identification) || identification.length() >34) {
			return false;
		}
		return true;
	}
	
}
