/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.account.information.boi.foundationservice.transformer;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capgemini.psd2.account.information.boi.foundationservice.constants.AccountInformationFoundationServiceConstants;
import com.capgemini.psd2.account.information.boi.foundationservice.domain.Accnt;
import com.capgemini.psd2.account.information.boi.foundationservice.validations.AccountInformationValidator;
import com.capgemini.psd2.adapter.exceptions.AdapterErrorCodeEnum;
import com.capgemini.psd2.adapter.exceptions.AdapterException;
import com.capgemini.psd2.aisp.domain.AccountGETResponse;
import com.capgemini.psd2.aisp.domain.AccountGETResponseAccount;
import com.capgemini.psd2.aisp.domain.AccountGETResponseData;
import com.capgemini.psd2.aisp.domain.AccountGETResponseServicer;
import com.capgemini.psd2.aisp.domain.AccountGETResponseAccount.SchemeNameEnum;
import com.capgemini.psd2.aisp.transformer.AccountInformationTransformer;
import com.capgemini.psd2.utilities.NullCheckUtils;

/**
 * The Class AccountInformationFoundationServiceTransformer.
 */
@Component
public class AccountInformationFoundationServiceTransformer implements AccountInformationTransformer {
	
	/** The account information validator. */
	@Autowired
	private AccountInformationValidator accountInformationValidator;

	/* (non-Javadoc)
	 * @see com.capgemini.psd2.aisp.transformer.AccountInformationTransformer#transformAccountInformation(java.lang.Object, java.util.Map)
	 */
	@Override
	public <T> AccountGETResponse transformAccountInformation(T inputAccountObj, Map<String, String> params) {
		AccountGETResponse finalAIResponseObj = new AccountGETResponse();
		Accnt accnt = (Accnt) inputAccountObj;
		if(!accountInformationValidator.validateCurrency(accnt.getCurrency())) {
			throw AdapterException.populatePSD2Exception(AdapterErrorCodeEnum.INVALID_CURRENCY);
		}
		if(!accountInformationValidator.validateNickName(accnt.getAccountName())) {
			throw AdapterException.populatePSD2Exception(AdapterErrorCodeEnum.INVALID_NICKNAME);
		}
		if(!accountInformationValidator.validateIdentification(accnt.getAccountNumber()) || !accountInformationValidator.validateIdentification(accnt.getIban())) {
			throw AdapterException.populatePSD2Exception(AdapterErrorCodeEnum.INVALID_IDENTIFICATION);
		}
		if(NullCheckUtils.isNullOrEmpty(params) || !accountInformationValidator.validateAccountId(params.get(AccountInformationFoundationServiceConstants.ACCOUNT_ID))) {
			throw AdapterException.populatePSD2Exception(AdapterErrorCodeEnum.NO_ACCOUNT_ID_FOUND);
		}
		AccountGETResponseData responseObj = new AccountGETResponseData();
		responseObj.setAccountId(params.get(AccountInformationFoundationServiceConstants.ACCOUNT_ID));
		AccountGETResponseAccount acc = new AccountGETResponseAccount();
		acc.setName(accnt.getAccountName());
		acc.setIdentification(accnt.getAccountNumber());
		if (!NullCheckUtils.isNullOrEmpty(accnt.getAccountNumber())) {
			acc.setSchemeName(SchemeNameEnum.BBAN);
		} else if (!NullCheckUtils.isNullOrEmpty(accnt.getIban())) {
			acc.setSchemeName(SchemeNameEnum.IBAN);
		}
		AccountGETResponseServicer servicer = new AccountGETResponseServicer();
		if (!NullCheckUtils.isNullOrEmpty(accnt.getAccountNsc())) {
			servicer.setSchemeName(com.capgemini.psd2.aisp.domain.AccountGETResponseServicer.SchemeNameEnum.UKSORTCODE);
			servicer.setIdentification(accnt.getAccountNsc());
		} else if (!NullCheckUtils.isNullOrEmpty(accnt.getIban())) {
			servicer.setSchemeName(com.capgemini.psd2.aisp.domain.AccountGETResponseServicer.SchemeNameEnum.BICFI);
			servicer.setIdentification(accnt.getBic());
		}
		responseObj.setAccount(acc);
		responseObj.setCurrency(accnt.getCurrency());
		responseObj.setNickname(accnt.getAccountName());
		responseObj.setServicer(servicer);
		finalAIResponseObj.getData().add(responseObj);
		return finalAIResponseObj;
	}

}
