/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.account.information.boi.foundationservice.adapter.test;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.capgemini.psd2.account.information.boi.foundationservice.adapter.AccountInformationFoundationServiceAdapter;
import com.capgemini.psd2.account.information.boi.foundationservice.config.test.AccountInformationFoundationServiceAdapterTestConfiguration;
import com.capgemini.psd2.account.information.boi.foundationservice.delegate.AccountInformationFoundationServiceDelegate;
import com.capgemini.psd2.account.information.boi.foundationservice.domain.Accnt;
import com.capgemini.psd2.account.information.boi.foundationservice.domain.Accounts;
import com.capgemini.psd2.adapter.exceptions.AdapterException;
import com.capgemini.psd2.aisp.domain.AccountGETResponse;
import com.capgemini.psd2.consent.domain.AccountDetails;
import com.capgemini.psd2.consent.domain.AccountMapping;
import com.capgemini.psd2.rest.client.sync.impl.RestClientSyncImpl;

/**
 * The Class AccountInformationFoundationServiceAdapterTest.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = AccountInformationFoundationServiceAdapterTestConfiguration.class)
public class AccountInformationFoundationServiceAdapterTest {

	
	/** The account information foundation service adapter. */
	@InjectMocks
	private AccountInformationFoundationServiceAdapter accountInformationFoundationServiceAdapter;
	
	/** The account information foundation service delegate. */
	@Mock
	private AccountInformationFoundationServiceDelegate accountInformationFoundationServiceDelegate;
	
	/** The rest client. */
	@Mock
	private RestClientSyncImpl restClient;
	
	/**
	 * Sets the up.
	 */
	@Before
	public void setUp(){
		MockitoAnnotations.initMocks(this);
	}
	
	/**
	 * Context loads.
	 */
	@Test
	public void contextLoads() {
	}
	
	/**
	 * Test account information FS.
	 */
	@Test
	public void testAccountInformationFS() {
		Accounts accounts = new Accounts();
		Accnt acc = new Accnt();
		acc.setAccountNumber("acct1234");
		acc.setAccountNsc("nsc1234");
		accounts.getAccount().add(acc);
		AccountMapping accountMapping = new AccountMapping();
		List<AccountDetails> accDetList = new ArrayList<AccountDetails>();
		AccountDetails accDet = new AccountDetails();
		accDet.setAccountId("12345");
		accDet.setAccountNSC("nsc1234");
		accDet.setAccountNumber("acct1234");
		accDetList.add(accDet);
		accountMapping.setAccountDetails(accDetList);
		accountMapping.setChannelId("test");
		accountMapping.setTppCID("test");
		accountMapping.setPsuId("test");
		Mockito.when(accountInformationFoundationServiceDelegate.getFoundationServiceURL(any(), any(), any())).thenReturn("http://localhost:8082/fs-accountEnquiry-service/services/AccountEnquiry/business/nsc1234/acc1234/account");
		Mockito.when(accountInformationFoundationServiceDelegate.restTransportForSingleAccountInformation(any(), any(), any())).thenReturn(accounts);
		Mockito.when(accountInformationFoundationServiceDelegate.transformResponseFromFDToAPI(any(), any())).thenReturn(new AccountGETResponse());
		Mockito.when(restClient.callForGet(any(), any(), any())).thenReturn(accounts);
		Mockito.when(accountInformationFoundationServiceDelegate.getAccountFromAccountList(acc.getAccountNumber(), accounts)).thenReturn(acc);
		accountInformationFoundationServiceAdapter.retrieveAccountInformation(accountMapping, new HashMap<String,String>());
	}
	
	/**
	 * Test account information accnt mapping as null.
	 */
	@Test(expected = AdapterException.class)
	public void testAccountInformationAccntMappingAsNull() {
				
		Mockito.when(accountInformationFoundationServiceDelegate.createRequestHeaders(anyObject(),anyObject())).thenReturn(new HttpHeaders());
		accountInformationFoundationServiceAdapter.retrieveAccountInformation(null, new HashMap<String,String>());
	}
	
	/**
	 * Test account information account as null.
	 */
	@Test(expected = AdapterException.class)
	public void testAccountInformationAccountAsNull() {
				
		Mockito.when(accountInformationFoundationServiceDelegate.restTransportForSingleAccountInformation(anyObject(),anyObject(),anyObject())).thenReturn(null);
		accountInformationFoundationServiceAdapter.retrieveAccountInformation(null, new HashMap<String,String>());
	}
	
	/**
	 * Test exception.
	 */
	@Test(expected = AdapterException.class)
	public void testException(){
		AccountMapping accountMapping = new AccountMapping();
		List<AccountDetails> accDetList = new ArrayList<AccountDetails>();
		AccountDetails accDet = new AccountDetails();
		accDet.setAccountId("12345");
		accDet.setAccountNSC("nsc1234");
		accDet.setAccountNumber("acct1234");
		accDetList.add(accDet);
		accountMapping.setAccountDetails(accDetList);
		accountMapping.setChannelId("test");
		accountMapping.setTppCID("test");
		accountMapping.setPsuId("test");
		Mockito.when(accountInformationFoundationServiceDelegate.getFoundationServiceURL(any(), any(), any())).thenReturn("http://localhost:8082/fs-accountEnquiry-service/services/AccountEnquiry/business/nsc1234/acc1234/account");
		Mockito.when(accountInformationFoundationServiceDelegate.restTransportForSingleAccountInformation(any(), any(), any())).thenReturn(null);
		Mockito.when(accountInformationFoundationServiceDelegate.transformResponseFromFDToAPI(any(), any())).thenReturn(new AccountGETResponse());
		accountInformationFoundationServiceAdapter.retrieveAccountInformation(accountMapping, new HashMap<String,String>());
	}
	

	/**
	 * Test null exception.
	 */
	@Test(expected = AdapterException.class)
	public void testNullException(){
		Accounts accounts = new Accounts();
		Accnt acc = new Accnt();
		acc.setAccountNumber("acct1234");
		acc.setAccountNsc("nsc1234");
		accounts.getAccount().add(acc);
		AccountMapping accountMapping = new AccountMapping();
		List<AccountDetails> accDetList = new ArrayList<AccountDetails>();
		AccountDetails accDet = new AccountDetails();
		accDet.setAccountId("12345");
		accDet.setAccountNSC("nsc1234");
		accDet.setAccountNumber("acct1234");
		accDetList.add(accDet);
		accountMapping.setAccountDetails(accDetList);
		accountMapping.setChannelId("test");
		accountMapping.setTppCID("test");
		accountMapping.setPsuId("test");
		Mockito.when(accountInformationFoundationServiceDelegate.getFoundationServiceURL(any(), any(), any())).thenReturn("http://localhost:8082/fs-accountEnquiry-service/services/AccountEnquiry/business/nsc1234/acc1234/account");
		Mockito.when(accountInformationFoundationServiceDelegate.restTransportForSingleAccountInformation(any(), any(), any())).thenReturn(accounts);
		
		Mockito.when(accountInformationFoundationServiceDelegate.getAccountFromAccountList(acc.getAccountNumber(), accounts)).thenReturn(null);
		Mockito.when(accountInformationFoundationServiceDelegate.transformResponseFromFDToAPI(any(), any())).thenReturn(new AccountGETResponse());
		accountInformationFoundationServiceAdapter.retrieveAccountInformation(accountMapping, new HashMap<String,String>());
	}
	
	
}
