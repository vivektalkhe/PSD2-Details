/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.account.information.boi.foundationservice.adapter.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.capgemini.psd2.account.information.boi.foundationservice.config.test.AccountInformationFoundationServiceAdapterTestConfiguration;
import com.capgemini.psd2.account.information.boi.foundationservice.domain.Accnt;
import com.capgemini.psd2.account.information.boi.foundationservice.domain.Accounts;
import com.capgemini.psd2.account.information.boi.foundationservice.transformer.AccountInformationFoundationServiceTransformer;
import com.capgemini.psd2.account.information.boi.foundationservice.validations.AccountInformationValidator;
import com.capgemini.psd2.account.information.boi.foundationservice.validations.AccountInformationValidatorImpl;
import com.capgemini.psd2.adapter.exceptions.AdapterException;
import com.capgemini.psd2.aisp.domain.AccountGETResponse;
import com.capgemini.psd2.aisp.domain.AccountGETResponseData;
import com.capgemini.psd2.consent.domain.AccountDetails;
import com.capgemini.psd2.consent.domain.AccountMapping;


/**
 * The Class AccountInformationFoundationServiceTransformerTest.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes=AccountInformationFoundationServiceAdapterTestConfiguration.class)
public class AccountInformationFoundationServiceTransformerTest {

	/** The account information FS transformer. */
	@InjectMocks
	private AccountInformationFoundationServiceTransformer accountInformationFSTransformer;
	
	/** The validator. */
	@Spy
	private AccountInformationValidator validator = new AccountInformationValidatorImpl();
	
	/**
	 * Sets the up.
	 */
	@Before
	public void setUp(){
		MockitoAnnotations.initMocks(this);
	}
	
	/**
	 * Test transform account information.
	 */
	@Test
	public void testTransformAccountInformation() {
		Map<String, String> params = new HashMap<>();
		params.put("accountId", "12345");
		Accounts accounts = new Accounts();
		Accnt acc = new Accnt();
		acc.setAccountNumber("acct1234");
		acc.setAccountNsc("nsc1234");
		acc.setCurrency("GBP");
		acc.setAccountName("BOI_PSD2");
		accounts.getAccount().add(acc);
		AccountMapping accountMapping = new AccountMapping();
		List<AccountDetails> accDetList = new ArrayList<AccountDetails>();
		AccountDetails accDet = new AccountDetails();
		accDet.setAccountId("12345");
		accDet.setAccountNSC("nsc1234");
		accDet.setAccountNumber("acct1234");
		accDetList.add(accDet);
		accountMapping.setAccountDetails(accDetList);
		accountMapping.setChannelId("test");
		accountMapping.setTppCID("test");
		accountMapping.setPsuId("test");
		
		AccountGETResponseData responseDataObj = new AccountGETResponseData();
		responseDataObj.setAccountId(params.get("accountId"));
		
		AccountGETResponse res = accountInformationFSTransformer.transformAccountInformation(accounts.getAccount().get(0), params);
		assertNotNull(res);
	}
	
	
	/**
	 * Test transform account information curr as null.
	 */
	@Test(expected = AdapterException.class)
	public void testTransformAccountInformationCurrAsNull() {
		Map<String, String> params = new HashMap<>();
		params.put("accountId", "12345");
		Accounts accounts = new Accounts();
		Accnt acc = new Accnt();
		acc.setAccountNumber("acct1234");
		acc.setAccountNsc("nsc1234");
		acc.setCurrency(null);
		acc.setAccountName("BOI_PSD2");
		accounts.getAccount().add(acc);
		AccountMapping accountMapping = new AccountMapping();
		List<AccountDetails> accDetList = new ArrayList<AccountDetails>();
		AccountDetails accDet = new AccountDetails();
		accDet.setAccountId("12345");
		accDet.setAccountNSC("nsc1234");
		accDet.setAccountNumber("acct1234");
		accDetList.add(accDet);
		accountMapping.setAccountDetails(accDetList);
		accountMapping.setChannelId("test");
		accountMapping.setTppCID("test");
		accountMapping.setPsuId("test");
		
		AccountGETResponseData responseDataObj = new AccountGETResponseData();
		responseDataObj.setAccountId(params.get("accountId"));
		
		AccountGETResponse res = accountInformationFSTransformer.transformAccountInformation(accounts.getAccount().get(0), params);
		assertNotNull(res);
	}
	
	/**
	 * Test transform account information acc number as null.
	 */
	@Test(expected = AdapterException.class)
	public void testTransformAccountInformationAccNumberAsNull() {
		Map<String, String> params = new HashMap<>();
		params.put("accountId", "12345");
		Accounts accounts = new Accounts();
		Accnt acc = new Accnt();
		acc.setAccountNumber(null);
		acc.setAccountNsc("nsc1234");
		acc.setCurrency("GBP");
		acc.setAccountName("BOI_PSD2");
		accounts.getAccount().add(acc);
		AccountMapping accountMapping = new AccountMapping();
		List<AccountDetails> accDetList = new ArrayList<AccountDetails>();
		AccountDetails accDet = new AccountDetails();
		accDet.setAccountId("12345");
		accDet.setAccountNSC("nsc1234");
		accDet.setAccountNumber("acct1234");
		accDetList.add(accDet);
		accountMapping.setAccountDetails(accDetList);
		accountMapping.setChannelId("test");
		accountMapping.setTppCID("test");
		accountMapping.setPsuId("test");
		
		AccountGETResponseData responseDataObj = new AccountGETResponseData();
		responseDataObj.setAccountId(params.get("accountId"));
		
		AccountGETResponse res = accountInformationFSTransformer.transformAccountInformation(accounts.getAccount().get(0), params);
		assertNotNull(res);
	}
	
	/**
	 * Test validator.
	 */
	@Test
	public void testValidator(){
		assertFalse(validator.validateNickName(null));
		assertFalse(validator.validateAccountId("25777777777771331777777777777777777777777777777777235613512356666612135555551661"));
		String test ="";
		for(int i=0;i<80;i++)
			test = test+i;
		assertFalse(validator.validateNickName(test));
		
	}
	
	/**
	 * Test transform account information account name is null.
	 */
	@Test(expected = AdapterException.class)
	public void testTransformAccountInformationAccountNameIsNull() {
		Map<String, String> params = new HashMap<>();
		params.put("accountId", "12345");
		Accounts accounts = new Accounts();
		Accnt acc = new Accnt();
		acc.setAccountNumber("acct1234");
		acc.setAccountNsc("nsc1234");
		acc.setCurrency("GBP");
		acc.setAccountName(null);
		accounts.getAccount().add(acc);
		AccountMapping accountMapping = new AccountMapping();
		List<AccountDetails> accDetList = new ArrayList<AccountDetails>();
		AccountDetails accDet = new AccountDetails();
		accDet.setAccountId("12345");
		accDet.setAccountNSC("nsc1234");
		accDet.setAccountNumber("acct1234");
		accDetList.add(accDet);
		accountMapping.setAccountDetails(accDetList);
		accountMapping.setChannelId("test");
		accountMapping.setTppCID("test");
		accountMapping.setPsuId("test");
		
		AccountGETResponseData responseDataObj = new AccountGETResponseData();
		responseDataObj.setAccountId(params.get("accountId"));
		
		AccountGETResponse res = accountInformationFSTransformer.transformAccountInformation(accounts.getAccount().get(0), params);
		assertNotNull(res);
	}
	
	/**
	 * Test transform account information params null.
	 */
	@Test(expected = AdapterException.class)
	public void testTransformAccountInformationParamsNull() {
		Accounts accounts = new Accounts();
		Accnt acc = new Accnt();
		acc.setAccountNumber("acct1234");
		acc.setAccountNsc("nsc1234");
		acc.setCurrency("GBP");
		acc.setAccountName("1234");
		accounts.getAccount().add(acc);
		AccountMapping accountMapping = new AccountMapping();
		List<AccountDetails> accDetList = new ArrayList<AccountDetails>();
		AccountDetails accDet = new AccountDetails();
		accDet.setAccountId("12345");
		accDet.setAccountNSC("nsc1234");
		accDet.setAccountNumber("acct1234");
		accDetList.add(accDet);
		accountMapping.setAccountDetails(accDetList);
		accountMapping.setChannelId("test");
		accountMapping.setTppCID("test");
		accountMapping.setPsuId("test");
		
		AccountGETResponse res = accountInformationFSTransformer.transformAccountInformation(accounts.getAccount().get(0), null);
		assertNotNull(res);
	}
	
	/**
	 * Test transform account information params account id null.
	 */
	@Test(expected = AdapterException.class)
	public void testTransformAccountInformationParamsAccountIdNull() {
		Map<String, String> params = new HashMap<>();
		params.put("accountId", null);
		Accounts accounts = new Accounts();
		Accnt acc = new Accnt();
		acc.setAccountNumber("acct1234");
		acc.setAccountNsc("nsc1234");
		acc.setCurrency("GBP");
		acc.setAccountName("1234");
		accounts.getAccount().add(acc);
		AccountMapping accountMapping = new AccountMapping();
		List<AccountDetails> accDetList = new ArrayList<AccountDetails>();
		AccountDetails accDet = new AccountDetails();
		accDet.setAccountId("12345");
		accDet.setAccountNSC("nsc1234");
		accDet.setAccountNumber("acct1234");
		accDetList.add(accDet);
		accountMapping.setAccountDetails(accDetList);
		accountMapping.setChannelId("test");
		accountMapping.setTppCID("test");
		accountMapping.setPsuId("test");
		
		AccountGETResponseData responseDataObj = new AccountGETResponseData();
		responseDataObj.setAccountId(params.get("accountId"));
		
		AccountGETResponse res = accountInformationFSTransformer.transformAccountInformation(accounts.getAccount().get(0), params);
		assertNotNull(res);
	}
	
	/**
	 * Test success with iban.
	 */
	@Test
	public void testSuccessWithIban() {
		Map<String, String> params = new HashMap<>();
		params.put("accountId", "12345");
		Accounts accounts = new Accounts();
		Accnt acc = new Accnt();
		acc.setIban("acct1234");
		acc.setAccountNsc("nsc1234");
		acc.setCurrency("GBP");
		acc.setAccountName("BOI_PSD2");
		accounts.getAccount().add(acc);
		AccountMapping accountMapping = new AccountMapping();
		List<AccountDetails> accDetList = new ArrayList<AccountDetails>();
		AccountDetails accDet = new AccountDetails();
		accDet.setAccountId("12345");
		accDet.setAccountNSC("nsc1234");
		accDet.setAccountNumber("acct1234");
		accDetList.add(accDet);
		accountMapping.setAccountDetails(accDetList);
		accountMapping.setChannelId("test");
		accountMapping.setTppCID("test");
		accountMapping.setPsuId("test");
		
		AccountGETResponseData responseDataObj = new AccountGETResponseData();
		responseDataObj.setAccountId(params.get("accountId"));
		
		AccountGETResponse res = accountInformationFSTransformer.transformAccountInformation(accounts.getAccount().get(0), params);
		assertNotNull(res);
	}
	
}
