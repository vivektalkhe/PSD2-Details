/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.account.information.boi.foundationservice.adapter.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.capgemini.psd2.account.information.boi.foundationservice.constants.AccountInformationFoundationServiceConstants;
import com.capgemini.psd2.account.information.boi.foundationservice.delegate.AccountInformationFoundationServiceDelegate;
import com.capgemini.psd2.account.information.boi.foundationservice.domain.Accnt;
import com.capgemini.psd2.account.information.boi.foundationservice.domain.Accounts;
import com.capgemini.psd2.account.information.boi.foundationservice.transformer.AccountInformationFoundationServiceTransformer;
import com.capgemini.psd2.adapter.exceptions.AdapterException;
import com.capgemini.psd2.aisp.domain.AccountGETResponse;
import com.capgemini.psd2.consent.domain.AccountDetails;
import com.capgemini.psd2.consent.domain.AccountMapping;
import com.capgemini.psd2.rest.client.model.RequestInfo;
import com.capgemini.psd2.rest.client.sync.impl.RestClientSyncImpl;

/**
 * The Class AccountInformationFoundationServiceDelegateTest.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes=AccountInformationFoundationServiceDelegateTest.class)
public class AccountInformationFoundationServiceDelegateTest {

	/** The delegate. */
	@InjectMocks
	private AccountInformationFoundationServiceDelegate delegate;
	
	/** The account information FS transformer. */
	@Mock
	private AccountInformationFoundationServiceTransformer accountInformationFSTransformer;
	
	/** The rest client. */
	@Mock
	private RestClientSyncImpl restClient;
	
	/** The env. */
	@Mock
	private Environment env;
	
	/**
	 * Sets the up.
	 */
	@Before
	public void setUp(){
		MockitoAnnotations.initMocks(this);
	}
	
	/**
	 * Context loads.
	 */
	@Test
	public void contextLoads() {
	}

	/**
	 * Test rest transport for single account information.
	 */
	@Test
	public void testRestTransportForSingleAccountInformation() {
		Map<String, String> params = new HashMap<>();
		params.put("accountId", "12345");
		Accounts accounts = new Accounts();
		Accnt acc = new Accnt();
		acc.setAccountNumber("acct1234");
		acc.setAccountNsc("nsc1234");
		accounts.getAccount().add(acc);
		AccountMapping accountMapping = new AccountMapping();
		List<AccountDetails> accDetList = new ArrayList<AccountDetails>();
		AccountDetails accDet = new AccountDetails();
		accDet.setAccountId("12345");
		accDet.setAccountNSC("nsc1234");
		accDet.setAccountNumber("acct1234");
		accDetList.add(accDet);
		accountMapping.setAccountDetails(accDetList);
		accountMapping.setChannelId("test");
		accountMapping.setTppCID("test");
		accountMapping.setPsuId("test");
		
		Mockito.when(restClient.callForGet(any(), any(), any())).thenReturn(accounts);
		
		RequestInfo requestInfo = new RequestInfo();
		requestInfo.setUrl("http://localhost:8082/fs-accountEnquiry-service/services/AccountEnquiry/business");
		
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("X-BOI-USER", "header user");
		httpHeaders.add("X-BOI-CHANNEL", "header channel");
		httpHeaders.add("X-BOI-WORKSTATION", "header workstation");
		httpHeaders.add("X-BOI-PLATFORM", "header platform");
		
		Accounts res = delegate.restTransportForSingleAccountInformation(requestInfo,Accounts.class,httpHeaders);
		assertNotNull(res);
	}

	/**
	 * Test get foundation service URL.
	 */
	@Test
	public void testGetFoundationServiceURL() {
		
		String accountNSC = "number";
		String accountNumber = "accountNumber"; 
		String channel = "BOL";
		String baseURL = "http://localhost:8082/fs-accountEnquiry-service/services/AccountEnquiry/business";
		String finalURL = "http://localhost:8082/fs-accountEnquiry-service/services/AccountEnquiry/business/number/accountNumber/account";
		//when(env.getProperty(any())).thenReturn(baseURL);
		when(env.getProperty(AccountInformationFoundationServiceConstants.FOUNDATION_SERVICE+"."+channel+"."+AccountInformationFoundationServiceConstants.BASE_URL)).thenReturn(baseURL);
		String testURL = delegate.getFoundationServiceURL(channel,accountNSC,accountNumber);
		assertEquals("Test for building URL failed.", finalURL, testURL);
		assertNotNull(testURL);
	}
	
	/**
	 * Test get foundation service with invalid URL.
	 */
	@Test
	public void testGetFoundationServiceWithInvalidURL() {
		
		String accountNSC = "number";
		String accountNumber = "accountNumber"; 
		String channel = "BOL"; 
		String baseURL = "http://localhost:8082/fs-accountEnquiry-service/services/AccountEnquiry";
		String finalURL = "http://localhost:8082/fs-accountEnquiry-service/services/AccountEnquiry/business/number/accountNumber/account";
		when(env.getProperty(AccountInformationFoundationServiceConstants.FOUNDATION_SERVICE+"."+channel+"."+AccountInformationFoundationServiceConstants.BASE_URL)).thenReturn(baseURL);
		String testURL = delegate.getFoundationServiceURL(channel,accountNSC,accountNumber);
		
		assertNotEquals("Test for building URL failed.", finalURL, testURL);
		assertNotNull(testURL);
	}
	
	/**
	 * Test get foundation service with account NSC as null.
	 */
	@Test(expected = AdapterException.class)
	public void testGetFoundationServiceWithAccountNSCAsNull() {
		
		String accountNSC = null;
		String accountNumber = "number"; 
		String baseURL = "http://localhost:8082/fs-accountEnquiry-service/services/AccountEnquiry/business";
		
		delegate.getFoundationServiceURL(accountNSC,accountNumber,baseURL);
		
		fail("Invalid account NSC");
	}
	
	/**
	 * Test get foundation service with account number as null.
	 */
	@Test(expected = AdapterException.class)
	public void testGetFoundationServiceWithAccountNumberAsNull() {
		
		String accountNSC = "nsc";
		String accountNumber = null; 
		String baseURL = "http://localhost:8082/fs-accountEnquiry-service/services/AccountEnquiry/business";
		
		delegate.getFoundationServiceURL(accountNSC,accountNumber,baseURL);
		
		fail("Invalid Account Number");
	}
	
	/**
	 * Test get foundation service with base URL as null.
	 */
	@Test(expected = AdapterException.class)
	public void testGetFoundationServiceWithBaseURLAsNull() {
		
		String accountNSC = "nsc";
		String accountNumber = "number"; 
		String baseURL = null;
		
		delegate.getFoundationServiceURL(accountNSC,accountNumber,baseURL);
		
		fail("Invalid base URL");
	}
	
	
	/**
	 * Test create request headers actual.
	 */
	@Test
	public void testCreateRequestHeadersActual() {
		
		AccountMapping accountMapping = new AccountMapping();
		accountMapping.setPsuId("userId");
		accountMapping.setChannelId("channelId");
		accountMapping.setCorrelationId("correlationId");
		
		HttpHeaders httpHeaders = new HttpHeaders();
		ReflectionTestUtils.setField(delegate, "userInReqHeader", "X-BOI-USER");
		ReflectionTestUtils.setField(delegate, "channelInReqHeader", "X-BOI-CHANNEL");
		ReflectionTestUtils.setField(delegate, "platformInReqHeader", "X-BOI-PLATFORM");
		ReflectionTestUtils.setField(delegate, "correlationIdInReqHeader", "X-CORRELATION-ID");
		
		httpHeaders = delegate.createRequestHeaders(new RequestInfo(), accountMapping);

		assertNotNull(httpHeaders);
	}
	
	/**
	 * Test get account from account list.
	 */
	@Test
	public void testGetAccountFromAccountList() {
		
		Accounts accounts = new Accounts();
		Accnt acc = new Accnt();
		acc.setAccountNumber("acct1234");
		acc.setAccountNsc("nsc1234");
		accounts.getAccount().add(acc);
		
		Accnt res = delegate.getAccountFromAccountList("acct1234", accounts);
		assertEquals("acct1234", res.getAccountNumber());
		
	}
	
	
	/**
	 * Test transform response from FD to API.
	 */
	@Test
	public void testTransformResponseFromFDToAPI() {
		Accounts accounts = new Accounts();
		Accnt acc = new Accnt();
		acc.setAccountNumber("acct1234");
		acc.setAccountNsc("nsc1234");
		accounts.getAccount().add(acc);
		AccountMapping accountMapping = new AccountMapping();
		List<AccountDetails> accDetList = new ArrayList<AccountDetails>();
		AccountDetails accDet = new AccountDetails();
		accDet.setAccountId("12345");
		accDet.setAccountNSC("nsc1234");
		accDet.setAccountNumber("acct1234");
		accDetList.add(accDet);
		accountMapping.setAccountDetails(accDetList);
		accountMapping.setChannelId("test");
		accountMapping.setTppCID("test");
		accountMapping.setPsuId("test");
		Mockito.when(delegate.transformResponseFromFDToAPI(any(), any())).thenReturn(new AccountGETResponse());
		AccountGETResponse res = delegate.transformResponseFromFDToAPI(acc, new HashMap<String,String>());
		assertNotNull(res);
		
		
	}

}
