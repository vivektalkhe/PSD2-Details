/*******************************************************************************
 * CAPGEMINI CONFIDENTIAL
 * __________________
 * 
 * Copyright (C) 2017 CAPGEMINI GROUP - All Rights Reserved
 *  
 * NOTICE:  All information contained herein is, and remains
 * the property of CAPGEMINI GROUP.
 * The intellectual and technical concepts contained herein
 * are proprietary to CAPGEMINI GROUP and may be covered
 * by patents, patents in process, and are protected by trade secret
 * or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from CAPGEMINI GROUP.
 ******************************************************************************/
package com.capgemini.psd2.adapter.exceptions;

/**
 * The Enum AdapterErrorCodeEnum.
 */
public enum AdapterErrorCodeEnum {

	/** The authentication failure error. */
	AUTHENTICATION_FAILURE_ERROR("500","You are not authorized to use this service","401"),
	
	/** The account not found. */
	ACCOUNT_NOT_FOUND("501","The request can not be processed,Account not found","404"),
	
	/** The account details not found. */
	ACCOUNT_DETAILS_NOT_FOUND("502","No account details found for the requested account(s)","404"),
	
	/** The technical error. */
	TECHNICAL_ERROR("503","Technical Error.Please try again later","500"),
	
	/** The bad request. */
	BAD_REQUEST("504","Bad request.Please check your request","400"),
	
	/** The no account data found. */
	NO_ACCOUNT_DATA_FOUND("505","No Account data found","404"),
	
	/** The no account data found foundation service. */
	NO_ACCOUNT_DATA_FOUND_FOUNDATION_SERVICE("506","No Account data found in foundation service","404"),
	
	/** The invalid amount. */
	INVALID_AMOUNT("507","Invalid amount found in foundation service","500"),
	
	/** The invalid currency. */
	INVALID_CURRENCY("508","Invalid currency found in foundation service","500"),
	
	/** The invalid nickname. */
	INVALID_NICKNAME("509","Invalid nick name found in foundation service","500"),
	
	/** The invalid identification. */
	INVALID_IDENTIFICATION("510","Invalid identification found in foundation service","500"),
	
	/** The no account id found. */
	NO_ACCOUNT_ID_FOUND("511","No Account ID found","404"),
	
	/** The no channel id in request. */
	NO_CHANNEL_ID_IN_REQUEST("512","No channel present in the request","400"),
	
	/** The no account nsc in request. */
	NO_ACCOUNT_NSC_IN_REQUEST("513","No account nsc present in the request","400");
	
	
	
	
	/** The error code. */
	private String errorCode;
	
	/** The error message. */
	private String errorMessage;
	
	/** The status code. */
	private String statusCode;

	/**
	 * Instantiates a new adapter error code enum.
	 *
	 * @param errorCode the error code
	 * @param errorMesssage the error messsage
	 * @param statusCode the status code
	 */
	AdapterErrorCodeEnum(String errorCode,String errorMesssage,String statusCode){
		this.errorCode=errorCode;
		this.errorMessage=errorMesssage;
		this.statusCode = statusCode;
	}

	/**
	 * Gets the error code.
	 *
	 * @return the error code
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * Gets the error message.
	 *
	 * @return the error message
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * Gets the status code.
	 *
	 * @return the status code
	 */
	public String getStatusCode() {
		return statusCode;
	}

}
