package com.capgemini.psd2.account.information.mock.foundationservice.test;

import org.junit.Test;


/**
 * The Class AccountInformationApplicationTest.
 */
public class AccountInformationApplicationTest {

	/**
	 * Context loads.
	 */
	@Test
	public void contextLoads() {
	}
	
}
